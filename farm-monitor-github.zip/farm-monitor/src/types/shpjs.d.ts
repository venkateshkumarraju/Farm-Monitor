declare module 'shpjs';
