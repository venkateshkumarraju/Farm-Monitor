export interface AoiFeature {
  type: 'Feature';
  geometry: GeoJSON.Polygon | GeoJSON.MultiPolygon;
  properties: Record<string, unknown> & { name?: string };
}

export interface SceneInfo {
  id: string;
  datetime: string; // ISO
  cloudCover: number; // 0-100
  bbox: number[];
  assets: Record<string, { href: string }>;
}

export type IndexId = 'ndvi' | 'ndmi' | 'ndwi' | 'savi' | 'bsi' | 'ndre' | 'evi';

/** Any layer that can be shown on the map: a computed index or the true-color satellite image. */
export type LayerId = IndexId | 'tci';

export interface IndexStats {
  mean: number;
  min: number;
  max: number;
  std: number;
  histogram: { bin: string; count: number }[];
  validPixels: number;
  // percent of valid area in each health class
  classes: { label: string; pct: number; color: string }[];
}

export interface AnalysisResult {
  indexId: LayerId;
  stats: IndexStats | null; // null for the true-color layer
  imageDataUrl: string;
  bounds: [[number, number], [number, number]]; // [[south,west],[north,east]]
  sceneId: string;
  sceneDate: string;
  computedAt: string;
}

export interface HistoryPoint {
  sceneId: string;
  date: string;
  ndviMean?: number;
  ndmiMean?: number;
  cloudCover: number;
}

export interface MonitoringState {
  aoi: AoiFeature | null;
  aoiName: string;
  fromDate: string; // ISO date the farmer started monitoring
  lastRunAt: string | null;
  history: HistoryPoint[];
}
