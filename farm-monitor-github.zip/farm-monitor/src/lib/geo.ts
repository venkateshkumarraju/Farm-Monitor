import shp from 'shpjs';
import type { AoiFeature } from '@/types';

/** Parse an uploaded AOI file (.zip shapefile, .geojson/.json) into a single polygon feature. */
export async function parseAoiFile(file: File): Promise<AoiFeature> {
  const name = file.name.toLowerCase();
  let gj: GeoJSON.GeoJSON | GeoJSON.GeoJSON[];
  if (name.endsWith('.zip')) {
    const buf = await file.arrayBuffer();
    gj = await shp(buf);
  } else if (name.endsWith('.geojson') || name.endsWith('.json')) {
    gj = JSON.parse(await file.text()) as GeoJSON.GeoJSON;
  } else {
    throw new Error('Please upload a zipped shapefile (.zip) or a GeoJSON file (.geojson).');
  }

  const features: GeoJSON.Feature[] = Array.isArray(gj)
    ? gj.flatMap((g) => g.type === 'FeatureCollection' ? g.features : [])
    : gj.type === 'FeatureCollection'
      ? gj.features
      : gj.type === 'Feature'
        ? [gj]
        : [{ type: 'Feature', geometry: gj, properties: {} }];

  const poly = features.find(
    (f) => f.geometry?.type === 'Polygon' || f.geometry?.type === 'MultiPolygon',
  );
  if (!poly) throw new Error('No polygon found in the file. Upload a shapefile containing your field boundary.');

  const geometry = poly.geometry as GeoJSON.Polygon | GeoJSON.MultiPolygon;

  // shpjs reprojects when a readable .prj is present. Reject coordinates that
  // cannot be WGS 84 longitude/latitude instead of silently misplacing the field.
  let bad = false;
  const check = (coords: unknown): void => {
    if (!Array.isArray(coords)) return;
    if (typeof coords[0] === 'number') {
      const [x, y] = coords;
      if (!Number.isFinite(x) || !Number.isFinite(y) || Math.abs(x) > 180 || Math.abs(y) > 90) bad = true;
    } else {
      coords.forEach(check);
    }
  };
  check(geometry.coordinates);
  if (bad) {
    throw new Error(
      'This shapefile is not in WGS 84 (EPSG:4326) coordinates. Reproject it to WGS 84 first '
      + '(in QGIS: right-click the layer → Export → Save Features As → CRS: EPSG:4326), then upload again.',
    );
  }

  return {
    type: 'Feature',
    geometry,
    properties: { ...poly.properties, name: poly.properties?.name ?? file.name.replace(/\.(zip|geojson|json)$/i, '') },
  };
}

/** [west, south, east, north] of any GeoJSON geometry. */
export function geoBBox(geom: GeoJSON.Geometry): [number, number, number, number] {
  let w = Infinity, s = Infinity, e = -Infinity, n = -Infinity;
  const walk = (coords: unknown): void => {
    if (!Array.isArray(coords)) return;
    if (typeof coords[0] === 'number') {
      const [x, y] = coords;
      if (x < w) w = x; if (x > e) e = x;
      if (y < s) s = y; if (y > n) n = y;
    } else {
      coords.forEach(walk);
    }
  };
  walk('coordinates' in geom ? geom.coordinates : undefined);
  if (![w, s, e, n].every(Number.isFinite)) throw new Error('The field geometry has no valid coordinates.');
  return [w, s, e, n];
}

/** Rough polygon area in hectares (spherical), excluding interior holes. */
export function areaHectares(geom: GeoJSON.Geometry): number {
  const ringArea = (ring: number[][]): number => {
    const R = 6378137;
    let sum = 0;
    for (let i = 0; i < ring.length - 1; i++) {
      const [x1, y1] = ring[i];
      const [x2, y2] = ring[i + 1];
      sum += (x2 - x1) * (Math.PI / 180) * (2 + Math.sin(y1 * Math.PI / 180) + Math.sin(y2 * Math.PI / 180));
    }
    return Math.abs((sum * R * R) / 2);
  };
  const polygonArea = (rings: number[][][]): number =>
    Math.max(0, ringArea(rings[0]) - rings.slice(1).reduce((sum, ring) => sum + ringArea(ring), 0));
  let total = 0;
  if (geom.type === 'Polygon') total = polygonArea(geom.coordinates as number[][][]);
  if (geom.type === 'MultiPolygon')
    total = geom.coordinates.reduce((acc, p) => acc + polygonArea(p as number[][][]), 0);
  return total / 10000;
}

/** Douglas-Peucker simplification (tolerance in degrees) to clean up hand-drawn polygons. */
export function simplifyPolygon(geom: GeoJSON.Polygon, tolerance = 0.00002): GeoJSON.Polygon {
  const simplifyRing = (ring: number[][]): number[][] => {
    if (ring.length <= 4) return ring;
    const pts = ring.slice(0, -1);
    const keep = new Array(pts.length).fill(false);
    keep[0] = keep[pts.length - 1] = true;
    const stack: [number, number][] = [[0, pts.length - 1]];
    const dist = (p: number[], a: number[], b: number[]): number => {
      const dx = b[0] - a[0], dy = b[1] - a[1];
      const len2 = dx * dx + dy * dy;
      const t = len2 ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len2)) : 0;
      const px = a[0] + t * dx, py = a[1] + t * dy;
      return Math.hypot(p[0] - px, p[1] - py);
    };
    while (stack.length) {
      const [a, b] = stack.pop()!;
      let maxD = 0, idx = -1;
      for (let i = a + 1; i < b; i++) {
        const d = dist(pts[i], pts[a], pts[b]);
        if (d > maxD) { maxD = d; idx = i; }
      }
      if (maxD > tolerance && idx > 0) {
        keep[idx] = true;
        stack.push([a, idx], [idx, b]);
      }
    }
    const out = pts.filter((_, i) => keep[i]);
    if (out.length < 3) return ring;
    out.push([...out[0]]);
    return out;
  };
  return { type: 'Polygon', coordinates: geom.coordinates.map(simplifyRing) as number[][][] };
}

/** A ready-to-try demo field in rural Punjab. */
export const DEMO_AOI: AoiFeature = {
  type: 'Feature',
  geometry: {
    type: 'Polygon',
    coordinates: [[
      [75.8000, 30.8650],
      [75.8120, 30.8650],
      [75.8120, 30.8750],
      [75.8000, 30.8750],
      [75.8000, 30.8650],
    ]],
  },
  properties: { name: 'Demo field – rural Punjab' },
};
