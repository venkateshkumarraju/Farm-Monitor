import type { SceneInfo } from '@/types';

/** Open STAC API: Element84 Earth Search — free, no key, CORS-enabled. */
const STAC_URL = 'https://earth-search.aws.element84.com/v1/search';

interface StacFeature {
  id: string;
  properties: { datetime: string; 'eo:cloud_cover'?: number };
  bbox: number[];
  assets: Record<string, { href: string }>;
}

export async function searchScenes(
  geometry: GeoJSON.Polygon | GeoJSON.MultiPolygon,
  fromDate: string,
  maxCloud = 40,
  limit = 30,
  signal?: AbortSignal,
): Promise<SceneInfo[]> {
  const res = await fetch(STAC_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal,
    body: JSON.stringify({
      collections: ['sentinel-2-l2a'],
      intersects: geometry,
      datetime: `${fromDate.slice(0, 10)}T00:00:00Z/..`,
      query: { 'eo:cloud_cover': { lt: maxCloud } },
      sortby: [{ field: 'properties.datetime', direction: 'desc' }],
      limit,
    }),
  });
  if (!res.ok) throw new Error(`Satellite search failed (${res.status}). Check your connection and retry.`);
  const data = await res.json() as { features?: StacFeature[] };
  return (data.features ?? []).map((f) => ({
    id: f.id,
    datetime: f.properties.datetime,
    cloudCover: f.properties['eo:cloud_cover'] ?? 0,
    bbox: f.bbox,
    assets: f.assets,
  }));
}

export const UPDATE_INTERVAL_DAYS = 10;

export interface UpdateStatus {
  nextUpdateAt: Date;
  daysRemaining: number;
  due: boolean;
}

/** Next refresh = last successful run + 10 days, anchored to the start date before the first run. */
export function updateStatus(fromDate: string, lastRunAt: string | null, now = new Date()): UpdateStatus {
  const anchor = lastRunAt ? new Date(lastRunAt) : new Date(fromDate);
  const intervalMs = UPDATE_INTERVAL_DAYS * 24 * 3600 * 1000;
  let next = new Date(anchor.getTime() + intervalMs);
  while (next.getTime() + intervalMs <= now.getTime()) next = new Date(next.getTime() + intervalMs);
  const due = now.getTime() >= next.getTime();
  return {
    nextUpdateAt: next,
    daysRemaining: Math.max(0, Math.ceil((next.getTime() - now.getTime()) / (24 * 3600 * 1000))),
    due,
  };
}

/** Every 10-day checkpoint from the farmer's start date until the supplied time. */
export function checkpoints(fromDate: string, now = new Date()): Date[] {
  const out: Date[] = [];
  const intervalMs = UPDATE_INTERVAL_DAYS * 24 * 3600 * 1000;
  let t = new Date(fromDate).getTime();
  while (t <= now.getTime()) {
    out.push(new Date(t));
    t += intervalMs;
  }
  return out;
}

/** Pick the best scene closest to a checkpoint date. */
export function sceneNear(scenes: SceneInfo[], date: Date): SceneInfo | null {
  if (!scenes.length) return null;
  let best = scenes[0];
  let bestD = Math.abs(new Date(scenes[0].datetime).getTime() - date.getTime());
  for (const s of scenes) {
    const d = Math.abs(new Date(s.datetime).getTime() - date.getTime());
    if (d < bestD) { best = s; bestD = d; }
  }
  return best;
}
