import type { IndexId, IndexStats, HistoryPoint } from '@/types';

export interface Decision {
  severity: 'good' | 'watch' | 'act';
  title: string;
  detail: string;
  action: string;
}

/** Turn index statistics into plain-language advice a farmer can act on. */
export function buildDecisions(
  indexId: IndexId,
  stats: IndexStats,
  prev?: HistoryPoint,
): Decision[] {
  const out: Decision[] = [];
  const { mean, std, classes } = stats;
  if (!Number.isFinite(mean)) return out;

  const pct = (label: string) => classes.find((c) => c.label === label)?.pct ?? 0;

  if (indexId === 'ndvi' || indexId === 'savi' || indexId === 'evi') {
    const stressed = pct('Bare / stressed');
    const healthy = pct('Healthy, dense crop') + pct('Healthy') + pct('Dense healthy');
    if (healthy >= 70) {
      out.push({
        severity: 'good',
        title: 'Crop looks healthy overall',
        detail: `${Math.round(healthy)}% of the field shows dense, vigorous growth (mean index ${mean.toFixed(2)}).`,
        action: 'Maintain the current irrigation and fertilizer schedule. Re-check after the next 10-day update.',
      });
    } else if (stressed >= 30) {
      out.push({
        severity: 'act',
        title: 'Large stressed or bare patches detected',
        detail: `${Math.round(stressed)}% of the field reads as bare soil or stressed vegetation.`,
        action: 'Walk the red zones on the map within 2–3 days: check for germination failure, pest attack, or water stress. Consider gap-filling / re-sowing where plants are missing.',
      });
    } else {
      out.push({
        severity: 'watch',
        title: 'Crop is developing but uneven',
        detail: `Mean index ${mean.toFixed(2)} with mixed vigour across the field.`,
        action: 'Compare the weak zones with irrigation coverage; uneven growth this early often traces back to uneven watering or seeding depth.',
      });
    }
    if (std > 0.15) {
      out.push({
        severity: 'watch',
        title: 'Growth is very uneven across the field',
        detail: `High variability (σ = ${std.toFixed(2)}) means some zones are far behind others.`,
        action: 'Treat zones separately: weaker patches may need a targeted top-dressing of nitrogen rather than a blanket application.',
      });
    }
    if (prev?.ndviMean !== undefined) {
      const delta = mean - prev.ndviMean;
      if (delta < -0.05) {
        out.push({
          severity: 'act',
          title: 'Crop health dropped since the last update',
          detail: `Mean NDVI fell from ${prev.ndviMean.toFixed(2)} to ${mean.toFixed(2)} between satellite passes.`,
          action: 'A sudden drop usually means water stress, pest/disease, or storm damage. Inspect the field today and check the moisture (NDMI) layer.',
        });
      } else if (delta > 0.05) {
        out.push({
          severity: 'good',
          title: 'Crop is gaining vigour',
          detail: `Mean NDVI rose by ${delta.toFixed(2)} since the previous pass.`,
          action: 'Growth is on track. Keep records — this trend is a good baseline for yield expectation.',
        });
      }
    }
  }

  if (indexId === 'ndmi') {
    const dry = pct('Dry – irrigate soon');
    const wet = pct('Well watered');
    if (dry >= 40) {
      out.push({
        severity: 'act',
        title: 'Field is drying out — irrigation needed',
        detail: `${Math.round(dry)}% of the field shows low canopy/soil moisture (mean NDMI ${mean.toFixed(2)}).`,
        action: 'Irrigate within 24–48 hours, prioritising the red zones. If water is limited, skip the already-wet blue zones.',
      });
    } else if (wet >= 70) {
      out.push({
        severity: 'good',
        title: 'Moisture is adequate',
        detail: `${Math.round(wet)}% of the field is well watered.`,
        action: 'Hold irrigation for now — over-watering wastes water and can leach fertilizer.',
      });
    } else {
      out.push({
        severity: 'watch',
        title: 'Moisture is borderline in places',
        detail: `Mean NDMI ${mean.toFixed(2)} — some zones are drying faster than others.`,
        action: 'Plan the next irrigation within the week, and check whether the dry zones align with sandy patches or irrigation dead-spots.',
      });
    }
  }

  if (indexId === 'ndwi') {
    const standing = pct('Standing water') + pct('Very wet');
    if (standing >= 20) {
      out.push({
        severity: 'act',
        title: 'Waterlogging detected',
        detail: `${Math.round(standing)}% of the field shows standing or near-standing water.`,
        action: 'Open drainage in the blue zones; prolonged waterlogging suffocates roots and invites fungal disease.',
      });
    } else {
      out.push({
        severity: 'good',
        title: 'No significant waterlogging',
        detail: 'Standing water is below 20% of the field.',
        action: 'No drainage action needed. Re-check after heavy rain or flood irrigation.',
      });
    }
  }

  if (indexId === 'bsi') {
    const exposed = pct('Exposed soil') + pct('Severely exposed');
    if (exposed >= 40) {
      out.push({
        severity: 'watch',
        title: 'Large share of soil is exposed',
        detail: `${Math.round(exposed)}% of the field is bare soil — normal before canopy closure, risky after it.`,
        action: 'If the crop is already established, exposed soil means poor stand or erosion. Mulch or cover-crop the worst zones to protect moisture and fertility.',
      });
    } else {
      out.push({
        severity: 'good',
        title: 'Soil is well covered by crop',
        detail: `Only ${Math.round(exposed)}% of the field reads as exposed soil.`,
        action: 'Good canopy cover also suppresses weeds — keep it that way.',
      });
    }
  }

  if (indexId === 'ndre') {
    const lowN = pct('Very low N') + pct('Low N');
    if (lowN >= 40) {
      out.push({
        severity: 'act',
        title: 'Nitrogen deficiency likely in large areas',
        detail: `${Math.round(lowN)}% of the field shows low canopy chlorophyll (mean NDRE ${mean.toFixed(2)}).`,
        action: 'Plan a urea / N top-dressing for the orange-red zones within the week. Confirm with a leaf colour chart before applying.',
      });
    } else if (lowN >= 15) {
      out.push({
        severity: 'watch',
        title: 'Some zones may need nitrogen',
        detail: `${Math.round(lowN)}% of the field reads low on chlorophyll.`,
        action: 'Spot-apply nitrogen only to weak zones — blanket application wastes money and pollutes groundwater.',
      });
    } else {
      out.push({
        severity: 'good',
        title: 'Nitrogen status looks adequate',
        detail: 'Chlorophyll levels are healthy across most of the field.',
        action: 'No additional nitrogen needed right now; re-check at the next growth stage.',
      });
    }
  }

  return out;
}
