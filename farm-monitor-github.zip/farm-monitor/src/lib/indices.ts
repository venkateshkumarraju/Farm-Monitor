// proj4 is loaded for lon/lat -> image-CRS (UTM) reprojection of the AOI bbox,
// so we can window-read only the pixels covering the farmer's field.
import proj4 from 'proj4';
import { fromUrl, type GeoTIFFImage } from 'geotiff';
import type { IndexId, IndexStats } from '@/types';

export interface IndexDef {
  id: IndexId;
  name: string;
  hindi: string;
  what: string; // plain-language meaning for farmers
  bands: string[]; // earth-search asset keys
  range: [number, number];
  colormap: [number, string][]; // value stops -> color
  classes: { label: string; test: (v: number) => boolean; color: string }[];
}

export const INDEX_DEFS: IndexDef[] = [
  {
    id: 'ndvi',
    name: 'NDVI – Crop health',
    hindi: 'फसल स्वास्थ्य',
    what: 'How green and vigorous your crop is. Green areas are healthy; red areas are bare or stressed.',
    bands: ['red', 'nir'],
    range: [-0.1, 0.9],
    colormap: [[-0.1, '#8c510a'], [0.1, '#d8b365'], [0.3, '#f6e8c3'], [0.45, '#c2e699'], [0.6, '#78c679'], [0.75, '#31a354'], [0.9, '#006837']],
    classes: [
      { label: 'Bare / stressed', test: (v) => v < 0.25, color: '#b35806' },
      { label: 'Sparse / early growth', test: (v) => v < 0.45, color: '#e08214' },
      { label: 'Moderate growth', test: (v) => v < 0.65, color: '#7fbf7b' },
      { label: 'Healthy, dense crop', test: () => true, color: '#1b7837' },
    ],
  },
  {
    id: 'ndmi',
    name: 'NDMI – Moisture',
    hindi: 'नमी',
    what: 'Water content in crop and topsoil. Blue = moist, red = dry. Use it to time irrigation.',
    bands: ['nir', 'swir16'],
    range: [-0.4, 0.6],
    colormap: [[-0.4, '#a6611a'], [-0.1, '#dfc27d'], [0.1, '#f5f5f5'], [0.3, '#80cdc1'], [0.6, '#018571']],
    classes: [
      { label: 'Dry – irrigate soon', test: (v) => v < 0.0, color: '#a6611a' },
      { label: 'Low moisture', test: (v) => v < 0.2, color: '#dfc27d' },
      { label: 'Adequate', test: (v) => v < 0.4, color: '#80cdc1' },
      { label: 'Well watered', test: () => true, color: '#018571' },
    ],
  },
  {
    id: 'ndwi',
    name: 'NDWI – Water / waterlogging',
    hindi: 'जलभराव',
    what: 'Detects standing water and waterlogged patches after rain or irrigation.',
    bands: ['green', 'nir'],
    range: [-0.5, 0.5],
    colormap: [[-0.5, '#f7f4e8'], [-0.1, '#c7e9c0'], [0.1, '#74c476'], [0.3, '#2b8cbe'], [0.5, '#08306b']],
    classes: [
      { label: 'Dry land / crop', test: (v) => v < 0.0, color: '#c7b98a' },
      { label: 'Moist surface', test: (v) => v < 0.15, color: '#74c476' },
      { label: 'Very wet', test: (v) => v < 0.3, color: '#2b8cbe' },
      { label: 'Standing water', test: () => true, color: '#08306b' },
    ],
  },
  {
    id: 'savi',
    name: 'SAVI – Soil-adjusted health',
    hindi: 'मिट्टी-समायोजित स्वास्थ्य',
    what: 'Like NDVI but corrected for bare-soil brightness — better in early growth when soil shows between plants.',
    bands: ['red', 'nir'],
    range: [-0.1, 0.9],
    colormap: [[-0.1, '#8c510a'], [0.1, '#d8b365'], [0.3, '#f6e8c3'], [0.45, '#c2e699'], [0.6, '#78c679'], [0.75, '#31a354'], [0.9, '#006837']],
    classes: [
      { label: 'Bare / stressed', test: (v) => v < 0.2, color: '#b35806' },
      { label: 'Sparse crop', test: (v) => v < 0.4, color: '#e08214' },
      { label: 'Moderate', test: (v) => v < 0.6, color: '#7fbf7b' },
      { label: 'Healthy', test: () => true, color: '#1b7837' },
    ],
  },
  {
    id: 'bsi',
    name: 'BSI – Bare soil exposure',
    hindi: 'खुली मिट्टी',
    what: 'How much bare soil is exposed. High values mean erosion and moisture-loss risk.',
    bands: ['blue', 'red', 'nir', 'swir16'],
    range: [-0.4, 0.4],
    colormap: [[-0.4, '#1b7837'], [-0.1, '#a6d96a'], [0.0, '#ffffbf'], [0.2, '#fdae61'], [0.4, '#7f3b08']],
    classes: [
      { label: 'Well covered', test: (v) => v < -0.05, color: '#1b7837' },
      { label: 'Partly covered', test: (v) => v < 0.1, color: '#a6d96a' },
      { label: 'Exposed soil', test: (v) => v < 0.25, color: '#fdae61' },
      { label: 'Severely exposed', test: () => true, color: '#7f3b08' },
    ],
  },
  {
    id: 'ndre',
    name: 'NDRE – Nitrogen / chlorophyll',
    hindi: 'नाइट्रोजन',
    what: 'Chlorophyll in the crop canopy — a proxy for nitrogen status and fertilizer need.',
    bands: ['nir', 'rededge1'],
    range: [-0.05, 0.6],
    colormap: [[-0.05, '#8c510a'], [0.1, '#d8b365'], [0.2, '#f6e8c3'], [0.3, '#c2e699'], [0.45, '#31a354'], [0.6, '#006837']],
    classes: [
      { label: 'Very low N', test: (v) => v < 0.15, color: '#b35806' },
      { label: 'Low N', test: (v) => v < 0.25, color: '#e08214' },
      { label: 'Adequate N', test: (v) => v < 0.4, color: '#7fbf7b' },
      { label: 'High chlorophyll', test: () => true, color: '#1b7837' },
    ],
  },
  {
    id: 'evi',
    name: 'EVI – Enhanced vegetation',
    hindi: 'उन्नत वनस्पति',
    what: 'A saturation-resistant vegetation index — stays accurate in dense, mature crops where NDVI flattens.',
    bands: ['blue', 'red', 'nir'],
    range: [-0.1, 0.9],
    colormap: [[-0.1, '#8c510a'], [0.1, '#d8b365'], [0.25, '#f6e8c3'], [0.4, '#c2e699'], [0.6, '#31a354'], [0.9, '#006837']],
    classes: [
      { label: 'Bare / stressed', test: (v) => v < 0.2, color: '#b35806' },
      { label: 'Sparse', test: (v) => v < 0.35, color: '#e08214' },
      { label: 'Moderate', test: (v) => v < 0.55, color: '#7fbf7b' },
      { label: 'Dense healthy', test: () => true, color: '#1b7837' },
    ],
  },
];

const MAX_GRID = 384; // px per side for the computed raster

export interface Raster { width: number; height: number; data: Float32Array }
/** Per-scene cache: NDVI and NDMI share their NIR download instead of reading it twice. */
export type RasterCache = Map<string, Promise<Raster>>;

function utmProj(epsg: number): string {
  if (epsg >= 32601 && epsg <= 32660) return `+proj=utm +zone=${epsg - 32600} +datum=WGS84 +units=m +no_defs`;
  if (epsg >= 32701 && epsg <= 32760) return `+proj=utm +zone=${epsg - 32700} +south +datum=WGS84 +units=m +no_defs`;
  throw new Error(`Unsupported image CRS EPSG:${epsg}`);
}

async function openBand(href: string): Promise<GeoTIFFImage> {
  const tiff = await fromUrl(href);
  return tiff.getImage();
}

interface WindowSpec {
  window: [number, number, number, number];
  geo: [number, number, number, number]; // geographic bounds of the window [w,s,e,n]
}

/** Compute the pixel window covering the AOI inside a COG, plus its geographic bounds. */
function windowForAoi(image: GeoTIFFImage, aoiBbox: [number, number, number, number]): WindowSpec {
  const geoKeys = (image as unknown as { geoKeys?: Record<string, number> }).geoKeys;
  const epsg: number = geoKeys?.ProjectedCSTypeGeoKey
    ?? (((aoiBbox[1] + aoiBbox[3]) / 2) >= 0 ? 32600 : 32700)
      + Math.floor(((aoiBbox[0] + aoiBbox[2]) / 2 + 180) / 6) + 1;
  const fwd = proj4('EPSG:4326', utmProj(epsg));

  // project the 4 AOI corners into the image CRS and take the enclosing box
  const [w, s, e, n] = aoiBbox;
  const pts = [fwd.forward([w, s]), fwd.forward([w, n]), fwd.forward([e, s]), fwd.forward([e, n])];
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of pts) {
    x0 = Math.min(x0, x); x1 = Math.max(x1, x);
    y0 = Math.min(y0, y); y1 = Math.max(y1, y);
  }

  const imgBbox = image.getBoundingBox(); // [minX, minY, maxX, maxY] projected
  x0 = Math.max(x0, imgBbox[0]); y0 = Math.max(y0, imgBbox[1]);
  x1 = Math.min(x1, imgBbox[2]); y1 = Math.min(y1, imgBbox[3]);
  if (x1 <= x0 || y1 <= y0) throw new Error('The selected scene does not cover your field. Pick another date.');

  const resX = image.getResolution()[0];
  const resY = image.getResolution()[1];
  const imgW = image.getWidth();
  const imgH = image.getHeight();
  const wx = Math.max(0, Math.floor((x0 - imgBbox[0]) / resX));
  const wy = Math.max(0, Math.floor((imgBbox[3] - y1) / Math.abs(resY)));
  const ww = Math.min(imgW - wx, Math.ceil((x1 - x0) / resX));
  const wh = Math.min(imgH - wy, Math.ceil((y1 - y0) / Math.abs(resY)));

  // geographic bounds of the read window (for the map overlay)
  const wx0 = imgBbox[0] + wx * resX;
  const wy1 = imgBbox[3] - wy * Math.abs(resY);
  const wx1 = wx0 + ww * resX;
  const wy0 = wy1 - wh * Math.abs(resY);
  const inv = proj4(utmProj(epsg), 'EPSG:4326');
  const c1 = inv.forward([wx0, wy0]);
  const c2 = inv.forward([wx1, wy1]);
  const geo: [number, number, number, number] = [
    Math.min(c1[0], c2[0]), Math.min(c1[1], c2[1]),
    Math.max(c1[0], c2[0]), Math.max(c1[1], c2[1]),
  ];
  return { window: [wx, wy, wx + ww, wy + wh], geo };
}

/** Read a band windowed to the AOI bbox, resampled to (width × height). */
async function readBand(
  href: string,
  aoiBbox: [number, number, number, number],
  width: number,
  height: number,
  outBbox: { current: [number, number, number, number] | null },
): Promise<Raster> {
  const image = await openBand(href);
  const spec = windowForAoi(image, aoiBbox);
  outBbox.current ??= spec.geo;

  const rasters = await image.readRasters({
    window: spec.window,
    width,
    height,
    resampleMethod: 'bilinear',
  });
  const arr = rasters[0] as unknown as Float32Array;
  const ndv = image.getGDALNoData();

  const data = new Float32Array(width * height);
  for (let i = 0; i < data.length; i++) {
    const v = arr[i];
    data[i] = ndv !== null && v === ndv ? NaN : v;
  }
  return { width, height, data };
}

const TCI_MAX_GRID = 512;

/** Read the scene's true-color (RGB) image clipped to the AOI and return it as a PNG layer. */
export async function readTrueColor(
  assets: Record<string, { href: string }>,
  aoiBbox: [number, number, number, number],
  aoiGeom: GeoJSON.Polygon | GeoJSON.MultiPolygon,
  onProgress?: (msg: string) => void,
): Promise<{ imageDataUrl: string; bounds: [[number, number], [number, number]] }> {
  const href = assets.visual?.href ?? assets.tci?.href;
  if (!href) throw new Error('True-color image is unavailable for this scene.');
  onProgress?.('Downloading true-color satellite image…');

  const image = await openBand(href);
  const spec = windowForAoi(image, aoiBbox);
  const ww = spec.window[2] - spec.window[0];
  const wh = spec.window[3] - spec.window[1];
  const aspect = Math.max(0.2, Math.min(5, ww / wh));
  const width = aspect >= 1 ? TCI_MAX_GRID : Math.round(TCI_MAX_GRID * aspect);
  const height = aspect >= 1 ? Math.round(TCI_MAX_GRID / aspect) : TCI_MAX_GRID;

  const rasters = await image.readRasters({
    window: spec.window,
    width,
    height,
    resampleMethod: 'bilinear',
  });
  const r = rasters[0] as unknown as Uint8Array | Uint16Array;
  const g = (rasters[1] ?? rasters[0]) as unknown as Uint8Array | Uint16Array;
  const b = (rasters[2] ?? rasters[0]) as unknown as Uint8Array | Uint16Array;
  const scale = r instanceof Uint16Array && (r as Uint16Array).some((v) => v > 255) ? 256 : 1;

  onProgress?.('Rendering satellite image…');
  // polygon mask: reuse the index masking helper on an all-ones alpha grid
  const alpha = new Float32Array(width * height).fill(1);
  maskToAoi(alpha, width, height, spec.geo, aoiGeom);

  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(width, height);
  for (let i = 0; i < width * height; i++) {
    const o = i * 4;
    img.data[o] = r[i] / scale;
    img.data[o + 1] = g[i] / scale;
    img.data[o + 2] = b[i] / scale;
    img.data[o + 3] = Number.isFinite(alpha[i]) ? 255 : 0;
  }
  ctx.putImageData(img, 0, 0);
  return {
    imageDataUrl: canvas.toDataURL('image/png'),
    bounds: [[spec.geo[1], spec.geo[0]], [spec.geo[3], spec.geo[2]]],
  };
}

export interface ComputedIndex {
  grid: Float32Array;
  width: number;
  height: number;
  bounds: [[number, number], [number, number]];
  stats: IndexStats;
}

/** Download the needed bands and compute a vegetation/moisture/soil index over the AOI. */
export async function computeIndex(
  def: IndexDef,
  assets: Record<string, { href: string }>,
  aoiBbox: [number, number, number, number],
  aoiGeom: GeoJSON.Polygon | GeoJSON.MultiPolygon,
  onProgress?: (msg: string) => void,
  cache: RasterCache = new Map(),
): Promise<ComputedIndex> {
  for (const b of def.bands) {
    if (!assets[b]) throw new Error(`Band ${b} is unavailable for this scene.`);
  }

  // grid size from AOI aspect ratio
  const [w, s, e, n] = aoiBbox;
  const aspect = Math.max(0.2, Math.min(5, ((e - w) * Math.cos(((s + n) / 2) * Math.PI / 180)) / (n - s || 1e-9)));
  const width = aspect >= 1 ? MAX_GRID : Math.round(MAX_GRID * aspect);
  const height = aspect >= 1 ? Math.round(MAX_GRID / aspect) : MAX_GRID;

  const outBbox: { current: [number, number, number, number] | null } = { current: null };
  const rasters: Record<string, Raster> = {};
  await Promise.all(def.bands.map(async (b) => {
    onProgress?.(`Downloading ${b} band…`);
    const cacheKey = `${b}:${width}x${height}`;
    let pending = cache.get(cacheKey);
    if (!pending) {
      pending = readBand(assets[b].href, aoiBbox, width, height, outBbox);
      cache.set(cacheKey, pending);
    }
    rasters[b] = await pending;
  }));

  onProgress?.('Computing index…');
  const grid = new Float32Array(width * height);
  const R = (b: string, i: number) => rasters[b].data[i] / 10000; // Sentinel-2 reflectance scale
  for (let i = 0; i < grid.length; i++) {
    let v = NaN;
    switch (def.id) {
      case 'ndvi': {
        const nir = R('nir', i), red = R('red', i);
        v = (nir - red) / (nir + red); break;
      }
      case 'ndmi': {
        const nir = R('nir', i), sw = R('swir16', i);
        v = (nir - sw) / (nir + sw); break;
      }
      case 'ndwi': {
        const g = R('green', i), nir = R('nir', i);
        v = (g - nir) / (g + nir); break;
      }
      case 'savi': {
        const nir = R('nir', i), red = R('red', i);
        v = 1.5 * (nir - red) / (nir + red + 0.5); break;
      }
      case 'bsi': {
        const sw = R('swir16', i), red = R('red', i), nir = R('nir', i), blue = R('blue', i);
        v = ((sw + red) - (nir + blue)) / ((sw + red) + (nir + blue)); break;
      }
      case 'ndre': {
        const nir = R('nir', i), re = R('rededge1', i);
        v = (nir - re) / (nir + re); break;
      }
      case 'evi': {
        const nir = R('nir', i), red = R('red', i), blue = R('blue', i);
        v = 2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1); break;
      }
    }
    grid[i] = Number.isFinite(v) ? v : NaN;
  }

  // mask to AOI polygon
  const boundsArr = outBbox.current!;
  maskToAoi(grid, width, height, boundsArr, aoiGeom);

  const stats = computeStats(grid, def);
  return {
    grid, width, height,
    bounds: [[boundsArr[1], boundsArr[0]], [boundsArr[3], boundsArr[2]]],
    stats,
  };
}

export function maskToAoi(
  grid: Float32Array,
  width: number,
  height: number,
  bbox: [number, number, number, number],
  geom: GeoJSON.Polygon | GeoJSON.MultiPolygon,
) {
  const rings: number[][][][] = geom.type === 'Polygon' ? [geom.coordinates as number[][][]] : (geom.coordinates as number[][][][]);
  const dx = (bbox[2] - bbox[0]) / width;
  const dy = (bbox[3] - bbox[1]) / height;
  const inRing = (x: number, y: number, ring: number[][]): boolean => {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [xi, yi] = ring[i]; const [xj, yj] = ring[j];
      if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  };
  for (let py = 0; py < height; py++) {
    for (let px = 0; px < width; px++) {
      const x = bbox[0] + (px + 0.5) * dx;
      const y = bbox[3] - (py + 0.5) * dy;
      const inside = rings.some((poly) => inRing(x, y, poly[0]) && !poly.slice(1).some((hole) => inRing(x, y, hole)));
      if (!inside) grid[py * width + px] = NaN;
    }
  }
}

export function computeStats(grid: Float32Array, def: IndexDef): IndexStats {
  let min = Infinity, max = -Infinity, sum = 0, sum2 = 0, n = 0;
  const bins = new Array(10).fill(0);
  const classCount = new Array(def.classes.length).fill(0);
  const [lo, hi] = def.range;
  for (const v of grid) {
    if (!Number.isFinite(v)) continue;
    n++;
    sum += v; sum2 += v * v;
    if (v < min) min = v;
    if (v > max) max = v;
    const b = Math.min(9, Math.max(0, Math.floor(((v - lo) / (hi - lo)) * 10)));
    bins[b]++;
    const ci = def.classes.findIndex((c) => c.test(v));
    if (ci >= 0) classCount[ci]++;
  }
  const mean = n ? sum / n : NaN;
  const std = n ? Math.sqrt(Math.max(0, sum2 / n - mean * mean)) : NaN;
  return {
    mean, min, max, std,
    validPixels: n,
    histogram: bins.map((c, i) => ({ bin: (lo + ((i + 0.5) * (hi - lo)) / 10).toFixed(2), count: c })),
    classes: def.classes.map((c, i) => ({
      label: c.label,
      color: c.color,
      pct: n ? Math.round((classCount[i] / n) * 1000) / 10 : 0,
    })),
  };
}

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/** Colorize the computed grid into a PNG data URL for the map overlay. */
export function renderIndexImage(c: ComputedIndex, def: IndexDef): string {
  const canvas = document.createElement('canvas');
  canvas.width = c.width; canvas.height = c.height;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(c.width, c.height);
  const stops = def.colormap.map(([v, col]) => [v, hexToRgb(col)] as const);
  const [lo, hi] = def.range;
  for (let i = 0; i < c.grid.length; i++) {
    const v = c.grid[i];
    const o = i * 4;
    if (!Number.isFinite(v)) { img.data[o + 3] = 0; continue; }
    const t = Math.min(0.9999, Math.max(0, (v - lo) / (hi - lo)));
    const val = lo + t * (hi - lo);
    let a = stops[0], b = stops[stops.length - 1];
    for (let k = 0; k < stops.length - 1; k++) {
      if (val >= stops[k][0] && val <= stops[k + 1][0]) { a = stops[k]; b = stops[k + 1]; break; }
    }
    const f = b[0] === a[0] ? 0 : (val - a[0]) / (b[0] - a[0]);
    img.data[o] = Math.round(a[1][0] + (b[1][0] - a[1][0]) * f);
    img.data[o + 1] = Math.round(a[1][1] + (b[1][1] - a[1][1]) * f);
    img.data[o + 2] = Math.round(a[1][2] + (b[1][2] - a[1][2]) * f);
    img.data[o + 3] = 235;
  }
  ctx.putImageData(img, 0, 0);
  return canvas.toDataURL('image/png');
}
