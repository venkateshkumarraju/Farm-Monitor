// Support for user-supplied imagery: Cartosat-2/3 products, drone mosaics, or any
// georeferenced GeoTIFF. Sentinel-2 stays the default source; this module only
// handles files the user already has.
import { fromBlob, type GeoTIFFImage } from 'geotiff';
import proj4 from 'proj4';
import { maskToAoi, computeStats, type ComputedIndex, type IndexDef } from './indices';
import type { LayerId } from '@/types';

export interface BandMapping {
  red?: number;
  green?: number;
  blue?: number;
  nir?: number;
  swir?: number;
  rededge?: number;
}

export interface UserImageInfo {
  file: File;
  bandCount: number;
  width: number;
  height: number;
  crsName: string;
  /** Per-band description strings read from GDAL metadata (index 0 = band 1); null when absent. */
  bandLabels: (string | null)[];
}

const MAX_GRID = 384;

type GeoKeys = Record<string, string | number | undefined>;
type GeoKeyImage = { getGeoKeys?: () => GeoKeys; geoKeys?: GeoKeys };

function geoKeysOf(image: GeoTIFFImage): GeoKeys | null {
  const source = image as unknown as GeoKeyImage;
  const keys = typeof source.getGeoKeys === 'function' ? source.getGeoKeys() : source.geoKeys;
  return keys ?? null;
}

/**
 * Read per-band names/descriptions from the GDAL_METADATA tag (42112).
 * Drone exporters (DJI Terra, Pix4D, ODM…) write items like
 * `<Item name="DESCRIPTION" sample="4">nir</Item>` — one per band (sample is 0-based).
 * geotiff 2.x keeps tag values behind the lazy ImageFileDirectory API, with a
 * plain-property fallback for older versions.
 */
async function readBandLabels(image: GeoTIFFImage, bandCount: number): Promise<(string | null)[]> {
  const labels: (string | null)[] = Array.from({ length: bandCount }, () => null);
  let raw = '';
  const fd = (image as unknown as {
    fileDirectory?: {
      hasTag?: (name: string) => boolean;
      loadValue?: (name: string) => Promise<unknown>;
      GDAL_METADATA?: unknown;
    };
  }).fileDirectory;
  try {
    if (fd?.hasTag?.('GDAL_METADATA') && fd.loadValue) {
      raw = String(await fd.loadValue('GDAL_METADATA') ?? '');
    } else if (typeof fd?.GDAL_METADATA === 'string') {
      raw = fd.GDAL_METADATA;
    }
  } catch { /* no readable metadata */ }
  const re = /<Item\b([^>]*)>([^<]*)<\/Item>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) {
    const sample = /sample="(\d+)"/i.exec(m[1])?.[1];
    const text = (m[2] || '').trim();
    if (sample !== undefined && text) {
      const i = Number(sample);
      if (i >= 0 && i < bandCount) labels[i] = text;
    }
  }
  return labels;
}

/** Inspect an uploaded GeoTIFF: band count, size, band labels, and a human-readable CRS label. */
export async function inspectUserImage(file: File): Promise<UserImageInfo> {
  const tiff = await fromBlob(file);
  const image = await tiff.getImage();
  const bandCount = image.getSamplesPerPixel();
  const keys = geoKeysOf(image);
  let crsName = 'WGS 84 (assumed from coordinates)';
  if (keys?.GTCitationGeoKey) crsName = String(keys.GTCitationGeoKey);
  else if (keys?.ProjectedCSTypeGeoKey) crsName = `EPSG:${keys.ProjectedCSTypeGeoKey}`;
  else if (keys?.GeographicTypeGeoKey) crsName = `EPSG:${keys.GeographicTypeGeoKey}`;
  return {
    file,
    bandCount,
    width: image.getWidth(),
    height: image.getHeight(),
    crsName,
    bandLabels: await readBandLabels(image, bandCount),
  };
}

/** Order matters: 'rededge' must be tested before 'red' ('red edge' contains 'red'). */
const BAND_KEYWORDS: [RegExp, keyof BandMapping][] = [
  [/red[-_ ]?edge|rededge|^re\b/i, 'rededge'],
  [/nir|near[-_ ]?infra/i, 'nir'],
  [/swir/i, 'swir'],
  [/red/i, 'red'],
  [/green|grn|^g\b/i, 'green'],
  [/blue|blu|^b\b/i, 'blue'],
];

export interface BandDetection {
  mapping: BandMapping;
  /** 'metadata' = band names found inside the file; 'heuristic' = guessed from band count/order. */
  source: 'metadata' | 'heuristic';
}

/**
 * Guess the band→channel mapping. Prefer the file's own band metadata; fall back to
 * common conventions: 3-band RGB, 4-band RGB+NIR (Cartosat-2 MX / typical drone export),
 * 5-band B,G,R,RE,NIR (MicaSense RedEdge / DJI P4 Multispectral).
 */
export function detectBandMapping(bandCount: number, labels: (string | null)[]): BandDetection {
  const mapping: BandMapping = {};
  let hits = 0;
  labels.forEach((label, i) => {
    if (!label) return;
    for (const [re, key] of BAND_KEYWORDS) {
      if (re.test(label)) {
        if (mapping[key] === undefined) { mapping[key] = i + 1; hits++; }
        break;
      }
    }
  });
  if (hits >= 2) return { mapping, source: 'metadata' };
  return { mapping: heuristicMapping(bandCount), source: 'heuristic' };
}

/** Band-count fallback used when the file carries no usable band names. */
export function heuristicMapping(bandCount: number): BandMapping {
  if (bandCount >= 5) return { blue: 1, green: 2, red: 3, rededge: 4, nir: 5 };
  if (bandCount === 4) return { red: 1, green: 2, blue: 3, nir: 4 };
  if (bandCount === 3) return { red: 1, green: 2, blue: 3 };
  return {};
}

/** @deprecated Use detectBandMapping() — kept for compatibility. */
export function defaultMapping(bandCount: number): BandMapping {
  return heuristicMapping(bandCount);
}

/** Which app layers this image can produce with the current band mapping. */
export function availableLayers(info: UserImageInfo, mapping: BandMapping): LayerId[] {
  const out: LayerId[] = [];
  const has = (k: keyof BandMapping) => mapping[k] !== undefined;
  if (info.bandCount === 1 || (has('red') && has('green') && has('blue'))) out.push('tci');
  if (has('red') && has('nir')) out.push('ndvi');
  if (has('green') && has('nir')) out.push('ndwi');
  if (has('nir') && has('swir')) out.push('ndmi');
  if (has('nir') && has('rededge')) out.push('ndre');
  if (has('blue') && has('red') && has('nir') && has('swir')) out.push('bsi');
  // EVI/SAVI need calibrated reflectance (additive constants) — not offered for raw uploads.
  return out;
}

interface WindowSpec {
  window: [number, number, number, number];
  geo: [number, number, number, number];
}

/** Pixel window covering the AOI, handling both geographic (4326) and UTM imagery. */
function windowFor(image: GeoTIFFImage, aoiBbox: [number, number, number, number]): WindowSpec {
  const keys = geoKeysOf(image);
  const imgBbox = image.getBoundingBox();
  const looksGeographic =
    keys?.GeographicTypeGeoKey === 4326 ||
    (keys?.ProjectedCSTypeGeoKey === undefined &&
      Math.abs(imgBbox[0]) <= 180 && Math.abs(imgBbox[2]) <= 180 &&
      Math.abs(imgBbox[1]) <= 90 && Math.abs(imgBbox[3]) <= 90);

  let toCrs: (xy: [number, number]) => [number, number];
  let toGeo: (xy: [number, number]) => [number, number];
  if (looksGeographic) {
    toCrs = (xy) => xy;
    toGeo = (xy) => xy;
  } else {
    const projected = keys?.ProjectedCSTypeGeoKey;
    const epsg = typeof projected === 'number' ? projected
      : (((aoiBbox[1] + aoiBbox[3]) / 2) >= 0 ? 32600 : 32700)
        + Math.floor(((aoiBbox[0] + aoiBbox[2]) / 2 + 180) / 6) + 1;
    const zone = epsg >= 32700 ? epsg - 32700 : epsg - 32600;
    const south = epsg >= 32700 ? ' +south' : '';
    const proj = `+proj=utm +zone=${zone}${south} +datum=WGS84 +units=m +no_defs`;
    const fwd = proj4('EPSG:4326', proj);
    const inv = proj4(proj, 'EPSG:4326');
    toCrs = (xy) => fwd.forward(xy) as [number, number];
    toGeo = (xy) => inv.forward(xy) as [number, number];
  }

  const [w, s, e, n] = aoiBbox;
  const pts = [toCrs([w, s]), toCrs([w, n]), toCrs([e, s]), toCrs([e, n])];
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of pts) {
    x0 = Math.min(x0, x); x1 = Math.max(x1, x);
    y0 = Math.min(y0, y); y1 = Math.max(y1, y);
  }
  x0 = Math.max(x0, imgBbox[0]); y0 = Math.max(y0, imgBbox[1]);
  x1 = Math.min(x1, imgBbox[2]); y1 = Math.min(y1, imgBbox[3]);
  if (x1 <= x0 || y1 <= y0) throw new Error('This image does not cover your field.');

  const resX = image.getResolution()[0];
  const resY = image.getResolution()[1];
  const imgW = image.getWidth();
  const imgH = image.getHeight();
  const wx = Math.max(0, Math.floor((x0 - imgBbox[0]) / resX));
  const wy = Math.max(0, Math.floor((imgBbox[3] - y1) / Math.abs(resY)));
  const ww = Math.min(imgW - wx, Math.ceil((x1 - x0) / resX));
  const wh = Math.min(imgH - wy, Math.ceil((y1 - y0) / Math.abs(resY)));

  const wx0 = imgBbox[0] + wx * resX;
  const wy1 = imgBbox[3] - wy * Math.abs(resY);
  const c1 = toGeo([wx0, wy1 - wh * Math.abs(resY)]);
  const c2 = toGeo([wx0 + ww * resX, wy1]);
  return {
    window: [wx, wy, wx + ww, wy + wh],
    geo: [Math.min(c1[0], c2[0]), Math.min(c1[1], c2[1]), Math.max(c1[0], c2[0]), Math.max(c1[1], c2[1])],
  };
}

async function readUserBand(
  image: GeoTIFFImage,
  band: number,
  spec: WindowSpec,
  width: number,
  height: number,
): Promise<Float32Array> {
  const rasters = await image.readRasters({
    window: spec.window,
    samples: [band - 1],
    width,
    height,
    resampleMethod: 'bilinear',
  });
  const arr = rasters[0] as unknown as ArrayLike<number>;
  const ndv = image.getGDALNoData();
  const data = new Float32Array(width * height);
  for (let i = 0; i < data.length; i++) {
    const v = arr[i];
    data[i] = ndv !== null && v === ndv ? NaN : v;
  }
  return data;
}

const BAND_KEY: Record<string, keyof BandMapping> = {
  red: 'red', green: 'green', blue: 'blue', nir: 'nir', swir16: 'swir', rededge1: 'rededge',
};

/** Compute an index from the uploaded image using the user's band mapping (raw DN values). */
export async function computeUserIndex(
  info: UserImageInfo,
  def: IndexDef,
  mapping: BandMapping,
  aoiBbox: [number, number, number, number],
  aoiGeom: GeoJSON.Polygon | GeoJSON.MultiPolygon,
  onProgress?: (msg: string) => void,
): Promise<ComputedIndex> {
  onProgress?.('Reading your image…');
  const tiff = await fromBlob(info.file);
  const image = await tiff.getImage();
  const spec = windowFor(image, aoiBbox);
  const ww = spec.window[2] - spec.window[0];
  const wh = spec.window[3] - spec.window[1];
  const aspect = Math.max(0.2, Math.min(5, ww / wh));
  const width = aspect >= 1 ? MAX_GRID : Math.round(MAX_GRID * aspect);
  const height = aspect >= 1 ? Math.round(MAX_GRID / aspect) : MAX_GRID;

  const bands: Record<string, Float32Array> = {};
  for (const b of def.bands) {
    const bandNo = mapping[BAND_KEY[b]];
    if (bandNo === undefined) throw new Error(`Band ${b} is not mapped for this image.`);
    onProgress?.(`Reading band ${bandNo}…`);
    bands[b] = await readUserBand(image, bandNo, spec, width, height);
  }

  onProgress?.('Computing index…');
  const grid = new Float32Array(width * height);
  for (let i = 0; i < grid.length; i++) {
    let v = NaN;
    switch (def.id) {
      case 'ndvi': {
        const nir = bands.nir[i], red = bands.red[i];
        v = (nir - red) / (nir + red); break;
      }
      case 'ndmi': {
        const nir = bands.nir[i], sw = bands.swir16[i];
        v = (nir - sw) / (nir + sw); break;
      }
      case 'ndwi': {
        const g = bands.green[i], nir = bands.nir[i];
        v = (g - nir) / (g + nir); break;
      }
      case 'bsi': {
        const sw = bands.swir16[i], red = bands.red[i], nir = bands.nir[i], blue = bands.blue[i];
        v = ((sw + red) - (nir + blue)) / ((sw + red) + (nir + blue)); break;
      }
      case 'ndre': {
        const nir = bands.nir[i], re = bands.rededge1[i];
        v = (nir - re) / (nir + re); break;
      }
      default:
        throw new Error(`${def.id.toUpperCase()} needs calibrated reflectance; it is not available for uploaded imagery.`);
    }
    grid[i] = Number.isFinite(v) ? v : NaN;
  }

  maskToAoi(grid, width, height, spec.geo, aoiGeom);
  return {
    grid, width, height,
    bounds: [[spec.geo[1], spec.geo[0]], [spec.geo[3], spec.geo[2]]],
    stats: computeStats(grid, def),
  };
}

/** Render the uploaded image's true-colour (or single-band grayscale) view clipped to the AOI. */
export async function renderUserTrueColor(
  info: UserImageInfo,
  mapping: BandMapping,
  aoiBbox: [number, number, number, number],
  aoiGeom: GeoJSON.Polygon | GeoJSON.MultiPolygon,
  onProgress?: (msg: string) => void,
): Promise<{ imageDataUrl: string; bounds: [[number, number], [number, number]] }> {
  onProgress?.('Reading your image…');
  const tiff = await fromBlob(info.file);
  const image = await tiff.getImage();
  const spec = windowFor(image, aoiBbox);
  const ww = spec.window[2] - spec.window[0];
  const wh = spec.window[3] - spec.window[1];
  const aspect = Math.max(0.2, Math.min(5, ww / wh));
  const width = aspect >= 1 ? 512 : Math.round(512 * aspect);
  const height = aspect >= 1 ? Math.round(512 / aspect) : 512;

  const gray = info.bandCount === 1;
  const bandNos = gray ? [1, 1, 1] : [mapping.red!, mapping.green!, mapping.blue!];
  onProgress?.('Rendering image…');
  const chans: Float32Array[] = [];
  for (const bn of bandNos) chans.push(await readUserBand(image, bn, spec, width, height));

  // per-channel 2–98% stretch so 16-bit products display naturally
  const stretch = (arr: Float32Array): [number, number] => {
    const vals = arr.filter(Number.isFinite).sort((a, b) => a - b);
    if (!vals.length) return [0, 255];
    return [vals[Math.floor(vals.length * 0.02)], vals[Math.floor(vals.length * 0.98)] || 1];
  };
  const ranges = chans.map(stretch);

  const alpha = new Float32Array(width * height).fill(1);
  maskToAoi(alpha, width, height, spec.geo, aoiGeom);

  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(width, height);
  for (let i = 0; i < width * height; i++) {
    const o = i * 4;
    for (let c = 0; c < 3; c++) {
      const [lo, hi] = ranges[c];
      const t = Math.min(1, Math.max(0, (chans[c][i] - lo) / (hi - lo || 1)));
      img.data[o + c] = Math.round(t * 255);
    }
    img.data[o + 3] = Number.isFinite(alpha[i]) ? 255 : 0;
  }
  ctx.putImageData(img, 0, 0);
  return {
    imageDataUrl: canvas.toDataURL('image/png'),
    bounds: [[spec.geo[1], spec.geo[0]], [spec.geo[3], spec.geo[2]]],
  };
}
