export interface RoadmapItem {
  title: string;
  status: 'implemented' | 'next';
  how: string;
  ref?: string;
}

/** Analyses the app runs today, plus the research-backed roadmap of what to add next. */
export const ANALYSIS_ROADMAP: RoadmapItem[] = [
  {
    title: 'NDVI crop-health mapping',
    status: 'implemented',
    how: 'NDVI from Sentinel-2 red/NIR at 10 m, classified into health zones with plain-language actions.',
    ref: 'Vidican et al. 2023, Agronomy — critical review of vegetation indices for crop monitoring',
  },
  {
    title: 'Soil & canopy moisture (NDMI)',
    status: 'implemented',
    how: 'NIR/SWIR moisture index flags dry zones for irrigation timing.',
    ref: 'Shokati et al. 2024, Remote Sensing — RF soil-moisture estimation with Sentinel-2',
  },
  {
    title: 'Waterlogging detection (NDWI)',
    status: 'implemented',
    how: 'Green/NIR index detects standing water after rain or flood irrigation.',
  },
  {
    title: 'Bare-soil exposure (BSI) & soil-adjusted health (SAVI)',
    status: 'implemented',
    how: 'Tracks erosion risk and corrects vigour readings in early growth stages.',
  },
  {
    title: 'Nitrogen status (NDRE)',
    status: 'implemented',
    how: 'Red-edge chlorophyll index proxies fertilizer need, zone by zone.',
    ref: 'Geng et al. 2024, Remote Sensing — crop-growth info improves soil-property prediction',
  },
  {
    title: '10-day change detection & alerts',
    status: 'implemented',
    how: 'Each refresh compares NDVI/NDMI with the previous pass and alerts on sudden drops.',
    ref: 'Farbo et al. 2024, ISPRS J. — forecasting corn NDVI from Sentinel-2 time series',
  },
  {
    title: 'Yield estimation (ML on index time series)',
    status: 'next',
    how: 'Train a Random-Forest / LSTM on the season’s NDVI-NDMI curve against past yields.',
    ref: 'Koohikeradeh et al. 2025, Sustainability — NDMI + ERA5 + LSTM for field-scale prediction',
  },
  {
    title: 'Soil fertility / SOC mapping with ground samples',
    status: 'next',
    how: 'Combine a one-time soil sampling campaign with spectral indices + ML to map N, P, K, organic carbon.',
    ref: 'Zhang et al. 2023, Agriculture; Zayani et al. 2023, Remote Sensing',
  },
  {
    title: 'Cloud-gap filling with Sentinel-1 SAR',
    status: 'next',
    how: 'Radar keeps the time series alive through the monsoon; SAR-optical fusion also refines moisture.',
    ref: 'Lee et al. 2023, Remote Sensing — DNN soil moisture from Sentinel-1 + 2',
  },
  {
    title: 'Variable-rate fertilizer prescription maps',
    status: 'next',
    how: 'Turn NDRE/NDVI zones into per-zone fertilizer doses exportable for spreaders.',
    ref: 'Winzeler et al. 2024, Remote Sensing — vegetation masking improves fertility prediction',
  },
  {
    title: 'Pest & disease risk zoning',
    status: 'next',
    how: 'Combine sudden NDVI drops with weather data to rank outbreak risk zones.',
  },
  {
    title: 'Per-field zonal statistics for multi-field farms',
    status: 'next',
    how: 'Upload several polygons and get per-field report cards and rankings.',
  },
];

export interface PaperRef {
  title: string;
  authors: string;
  year: number;
  venue: string;
  url: string;
  usedFor: string;
}

/** Latest research (2023–2026) the indices and decisions in this app are based on. */
export const REFERENCES: PaperRef[] = [
  {
    title: 'Using remote sensing vegetation indices for the discrimination and monitoring of agricultural crops: a critical review',
    authors: 'R. Vidican, A. Mălinaș, O. Ranta, et al.',
    year: 2023, venue: 'Agronomy (MDPI)',
    url: 'https://www.mdpi.com/2073-4395/13/12/3040',
    usedFor: 'NDVI / S2REP index selection & growth-stage interpretation',
  },
  {
    title: 'Forecasting corn NDVI through AI-based approaches using Sentinel-2 image time series',
    authors: 'A. Farbo, F. Sarvia, S. De Petris, et al.',
    year: 2024, venue: 'ISPRS Journal of Photogrammetry and Remote Sensing',
    url: 'https://www.sciencedirect.com/science/article/pii/S0924271624001722',
    usedFor: '7-day time-series design & NDVI trend alerts',
  },
  {
    title: 'Random forest-based soil moisture estimation using Sentinel-2, Landsat-8/9, and UAV-based hyperspectral data',
    authors: 'H. Shokati, M. Mashal, A. Noroozi, et al.',
    year: 2024, venue: 'Remote Sensing (MDPI)',
    url: 'https://www.mdpi.com/2072-4292/16/11/1962',
    usedFor: 'NDMI moisture layer & irrigation decisions',
  },
  {
    title: 'NDMI-derived field-scale soil moisture prediction using ERA5 and LSTM for precision agriculture',
    authors: 'E. Koohikeradeh, S. J. Gumiere, H. Bonakdari',
    year: 2025, venue: 'Sustainability (MDPI)',
    url: 'https://www.mdpi.com/2071-1050/17/6/2399',
    usedFor: 'Moisture forecasting roadmap',
  },
  {
    title: 'Estimation of high-resolution soil moisture in Canadian croplands using deep neural network with Sentinel-1 and Sentinel-2 images',
    authors: 'S. J. Lee, C. Choi, J. Kim, et al.',
    year: 2023, venue: 'Remote Sensing (MDPI)',
    url: 'https://www.mdpi.com/2072-4292/15/16/4063',
    usedFor: 'SAR-optical fusion roadmap for monsoon cloud gaps',
  },
  {
    title: 'Assessing how irrigation practices and soil moisture affect crop growth through monitoring Sentinel-1 and Sentinel-2 data',
    authors: 'G. R. F. Ibrahim, A. Rasul, H. Abdullah',
    year: 2023, venue: 'Environmental Monitoring and Assessment (Springer)',
    url: 'https://link.springer.com/article/10.1007/s10661-023-11871-w',
    usedFor: 'Irrigation-impact thresholds in the decision engine',
  },
  {
    title: 'Mapping cropland soil nutrients contents based on multi-spectral remote sensing and machine learning',
    authors: 'W. Zhang, L. Zhu, Q. Zhuang, et al.',
    year: 2023, venue: 'Agriculture (MDPI)',
    url: 'https://www.mdpi.com/2077-0472/13/8/1592',
    usedFor: 'Soil-fertility mapping roadmap (N, P, K from spectra + ML)',
  },
  {
    title: 'Using machine-learning algorithms to predict soil organic carbon content from combined remote sensing imagery and laboratory vis-NIR spectral datasets',
    authors: 'H. Zayani, Y. Fouad, D. Michot, et al.',
    year: 2023, venue: 'Remote Sensing (MDPI)',
    url: 'https://www.mdpi.com/2072-4292/15/17/4264',
    usedFor: 'Soil organic carbon / fertility roadmap',
  },
  {
    title: 'Vegetation masking of remote sensing data aids machine learning for soil fertility prediction',
    authors: 'H. E. Winzeler, M. Mancini, J. M. Blackstock, et al.',
    year: 2024, venue: 'Remote Sensing (MDPI)',
    url: 'https://www.mdpi.com/2072-4292/16/17/3297',
    usedFor: 'Bare-soil handling in fertility models',
  },
  {
    title: 'Leveraging remote sensing-derived dynamic crop growth information for improved soil property prediction in farmlands',
    authors: 'J. Geng, Q. Tan, Y. Zhang, et al.',
    year: 2024, venue: 'Remote Sensing (MDPI)',
    url: 'https://www.mdpi.com/2072-4292/16/15/2731',
    usedFor: 'Linking NDVI dynamics to soil-property prediction',
  },
  {
    title: 'High-resolution surface soil moisture estimation over tropical agricultural land leveraging Sentinel-2 products and neural networks',
    authors: 'A. Atnurkar, M. Ramadas, R. Parwin',
    year: 2026, venue: 'Journal of Earth System Science (Springer)',
    url: 'https://link.springer.com/article/10.1007/s12040-026-02972-4',
    usedFor: 'Tropical-condition moisture tuning (relevant for Indian farms)',
  },
  {
    title: 'Soil Fertility Assessment by Integrating Optimized Vis–NIR Spectroscopy, Sentinel-2 Imagery, DEM-Derived Variables, and Machine Learning',
    authors: 'S. Nazari, S. Ayoubi, M. Rostaminia, et al.',
    year: 2026, venue: 'Communications in Soil Science and Plant Analysis',
    url: 'https://www.tandfonline.com/doi/abs/10.1080/00103624.2026.2765528',
    usedFor: 'Integrated Soil Fertility Index roadmap',
  },
];
