import { useCallback, useEffect, useMemo, useState } from 'react';
import type { AoiFeature, MonitoringState, HistoryPoint } from '@/types';

const KEY = 'farm-gis-monitor-v1';

const DEFAULT_STATE: MonitoringState = {
  aoi: null,
  aoiName: '',
  fromDate: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString().slice(0, 10),
  lastRunAt: null,
  history: [],
};

export function useMonitoring() {
  const [state, setState] = useState<MonitoringState>(() => {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? { ...DEFAULT_STATE, ...JSON.parse(raw) } : DEFAULT_STATE;
    } catch {
      return DEFAULT_STATE;
    }
  });

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* quota */ }
  }, [state]);

  const setAoi = useCallback((aoi: AoiFeature | null, name: string) => {
    // a new field means a new season history
    setState((s) => ({ ...s, aoi, aoiName: name, history: [], lastRunAt: null }));
  }, []);

  const setFromDate = useCallback((fromDate: string) => {
    setState((s) => ({ ...s, fromDate }));
  }, []);

  const markRun = useCallback(() => {
    setState((s) => ({ ...s, lastRunAt: new Date().toISOString() }));
  }, []);

  const pushHistory = useCallback((point: HistoryPoint) => {
    setState((s) => {
      // merge into the existing row for this scene so NDVI and NDMI points coexist
      const existing = s.history.find((h) => h.sceneId === point.sceneId);
      const merged = existing ? { ...existing, ...point } : point;
      const history = s.history.filter((h) => h.sceneId !== point.sceneId);
      history.push(merged);
      history.sort((a, b) => a.date.localeCompare(b.date));
      return { ...s, history: history.slice(-40) };
    });
  }, []);

  const reset = useCallback(() => setState(DEFAULT_STATE), []);

  return useMemo(
    () => ({ state, setAoi, setFromDate, markRun, pushHistory, reset }),
    [state, setAoi, setFromDate, markRun, pushHistory, reset],
  );
}
