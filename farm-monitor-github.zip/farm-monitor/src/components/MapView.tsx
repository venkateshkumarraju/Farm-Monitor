import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-draw/dist/leaflet.draw.css';
import type { AoiFeature, AnalysisResult } from '@/types';

interface Props {
  aoi: AoiFeature | null;
  overlay: AnalysisResult | null;
  opacity?: number;
  /** Increment to re-zoom the map to the AOI boundary. */
  zoomSignal?: number;
  /** Called when the user finishes drawing a field polygon on the map. */
  onAoiDrawn?: (feature: GeoJSON.Feature<GeoJSON.Polygon>) => void;
}

export default function MapView({ aoi, overlay, opacity = 0.9, zoomSignal = 0, onAoiDrawn }: Props) {
  const elRef = useRef<HTMLDivElement>(null);
  const coordsRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const aoiLayerRef = useRef<L.Layer | null>(null);
  const overlayRef = useRef<L.ImageOverlay | null>(null);
  const drawnRef = useRef<L.FeatureGroup | null>(null);
  const [mapReady, setMapReady] = useState(0);
  // keep the latest callback so the draw handler never goes stale
  const onAoiDrawnRef = useRef(onAoiDrawn);
  onAoiDrawnRef.current = onAoiDrawn;

  useEffect(() => {
    let cancelled = false;

    const initialiseMap = async () => {
      // leaflet-draw's UMD bundle reads window.L when it is evaluated. Load it
      // only after registering Leaflet, including in the optimized production build.
      (window as unknown as { L: typeof L }).L = L;
      await import('leaflet-draw');
      if (cancelled || !elRef.current || mapRef.current) return;

      const map = L.map(elRef.current, { zoomControl: true, attributionControl: true }).setView([22.5, 79.5], 5);
      const osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors',
      });
      const esri = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        { maxZoom: 19, attribution: 'Esri, Maxar, Earthstar Geographics' },
      );
      const topo = L.tileLayer('https://tile.opentopomap.org/{z}/{x}/{y}.png', {
        maxZoom: 17,
        attribution: '&copy; OpenStreetMap contributors, SRTM | style: &copy; OpenTopoMap (CC-BY-SA)',
      });
      esri.addTo(map);
      L.control.layers(
        { Satellite: esri, Topo: topo, Map: osm },
        {},
        { position: 'topright' },
      ).addTo(map);
      L.control.scale({ imperial: false, position: 'bottomleft' }).addTo(map);

      // draw toolbar: polygon only — for sketching the field boundary directly
      const drawn = new L.FeatureGroup().addTo(map);
      drawnRef.current = drawn;
      const drawControl = new L.Control.Draw({
        position: 'topright', // left side is covered by the contents panel
        draw: {
          polygon: {
            allowIntersection: false,
            shapeOptions: { color: '#354F52', weight: 3, fillColor: '#84A98C', fillOpacity: 0.14 },
          },
          polyline: false,
          rectangle: false,
          circle: false,
          circlemarker: false,
          marker: false,
        },
        edit: { featureGroup: drawn, edit: false, remove: false },
      });
      map.addControl(drawControl);
      map.on(L.Draw.Event.CREATED, (e: L.LeafletEvent) => {
        drawn.clearLayers();
        const layer = (e as L.DrawEvents.Created).layer as L.Polygon;
        const gj = layer.toGeoJSON() as GeoJSON.Feature<GeoJSON.Polygon>;
        drawn.addLayer(layer);
        onAoiDrawnRef.current?.(gj);
      });

      map.on('mousemove', (e: L.LeafletMouseEvent) => {
        if (coordsRef.current) {
          coordsRef.current.textContent = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
        }
      });
      mapRef.current = map;
      setMapReady((n) => n + 1);
    };

    void initialiseMap();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  // AOI polygon
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    aoiLayerRef.current?.remove();
    aoiLayerRef.current = null;
    // once the AOI is accepted, drop the sketch layer to avoid double outlines
    drawnRef.current?.clearLayers();
    if (!aoi) return;
    const layer = L.geoJSON(aoi as GeoJSON.Feature, {
      style: { color: '#CAD2C5', weight: 3, dashArray: '6 4', fillColor: '#84A98C', fillOpacity: 0.14 },
    }).addTo(map);
    aoiLayerRef.current = layer;
    map.fitBounds(layer.getBounds().pad(0.3));
  }, [aoi, mapReady]);

  // zoom-to-layer signal
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !zoomSignal || !aoiLayerRef.current) return;
    map.flyToBounds((aoiLayerRef.current as L.GeoJSON).getBounds().pad(0.2), { duration: 0.6 });
  }, [zoomSignal, mapReady]);

  // computed index overlay
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    overlayRef.current?.remove();
    overlayRef.current = null;
    if (!overlay) return;
    overlayRef.current = L.imageOverlay(overlay.imageDataUrl, overlay.bounds, { opacity, interactive: false }).addTo(map);
  }, [overlay, opacity, mapReady]);

  return (
    <>
      <div ref={elRef} className="h-full w-full" aria-label="Farm map" />
      <div
        ref={coordsRef}
        className="pointer-events-none absolute bottom-1 left-14 z-[500] rounded bg-white/80 px-1.5 py-0.5 font-mono text-[11px] text-stone-600"
        aria-hidden
      />
    </>
  );
}
