import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CloudRain, Droplets, FileImage, FlaskConical, Image as ImageIcon, Layers, Leaf, LineChart,
  Loader2, MapPin, Maximize2, PanelLeftClose, PanelLeftOpen, PenLine, RefreshCw, Satellite,
  Sprout, Tractor, Upload, AlertTriangle, CheckCircle2, BookOpen, ListChecks,
  CalendarClock, Waves,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import MapView from '@/components/MapView';
import { useMonitoring } from '@/hooks/useMonitoring';
import { parseAoiFile, geoBBox, areaHectares, simplifyPolygon, DEMO_AOI } from '@/lib/geo';
import { searchScenes, updateStatus, UPDATE_INTERVAL_DAYS } from '@/lib/stac';
import { INDEX_DEFS, computeIndex, renderIndexImage, readTrueColor, type IndexDef, type RasterCache } from '@/lib/indices';
import {
  inspectUserImage, detectBandMapping, availableLayers, computeUserIndex, renderUserTrueColor,
  type UserImageInfo, type BandMapping,
} from '@/lib/userImagery';
import { buildDecisions } from '@/lib/decisions';
import { ANALYSIS_ROADMAP, REFERENCES } from '@/lib/roadmap';
import type { SceneInfo, AnalysisResult, IndexId, LayerId, AoiFeature } from '@/types';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from 'recharts';

function errorMessage(error: unknown): string | null {
  return error instanceof Error ? error.message : null;
}

const INDEX_ICONS: Record<IndexId, typeof Leaf> = {
  ndvi: Leaf, ndmi: Droplets, ndwi: Waves, savi: Sprout, bsi: Tractor, ndre: FlaskConical, evi: LineChart,
};

const LAYER_LABELS: Record<LayerId, string> = {
  tci: 'Satellite image', ndvi: 'NDVI', ndmi: 'NDMI', ndwi: 'NDWI',
  savi: 'SAVI', bsi: 'BSI', ndre: 'NDRE', evi: 'EVI',
};

export default function App() {
  const { state, setAoi, setFromDate, markRun, pushHistory, reset } = useMonitoring();
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [scenes, setScenes] = useState<SceneInfo[]>([]);
  const [scenesLoading, setScenesLoading] = useState(false);
  const [sceneError, setSceneError] = useState<string | null>(null);
  const [selectedScene, setSelectedScene] = useState<SceneInfo | null>(null);
  const [maxCloud, setMaxCloud] = useState(40);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState<IndexId>('ndvi');
  const [layers, setLayers] = useState<Record<string, AnalysisResult>>({});
  const [overlayOpacity, setOverlayOpacity] = useState(0.9);
  const [zoomSignal, setZoomSignal] = useState(0);
  const [panelOpen, setPanelOpen] = useState(() => typeof window === 'undefined' || window.innerWidth >= 1024);
  const [fileInputKey, setFileInputKey] = useState(0);
  const [userImg, setUserImg] = useState<(UserImageInfo & { mapping: BandMapping; mappingSource: 'metadata' | 'heuristic' }) | null>(null);
  const [imgError, setImgError] = useState<string | null>(null);
  const [imgLoading, setImgLoading] = useState(false);
  const [autoProgress, setAutoProgress] = useState<{ done: number; total: number } | null>(null);
  // mirror of computed layers + cancellation token for the background trend analysis
  const layersRef = useRef<Record<string, AnalysisResult>>({});
  const trendTokenRef = useRef(0);
  useEffect(() => { layersRef.current = layers; }, [layers]);

  const aoiBBox = state.aoi ? geoBBox(state.aoi.geometry) : null;
  const aoiArea = state.aoi ? areaHectares(state.aoi.geometry) : 0;
  const status = updateStatus(state.fromDate, state.lastRunAt);

  /* ---------- AOI: upload, demo, or drawn on the map ---------- */
  // wipe per-field workspace state and cancel any running search / background trend analysis
  const clearWorkspace = useCallback(() => {
    trendTokenRef.current++;
    searchSeqRef.current++;
    searchAbortRef.current?.abort();
    setScenesLoading(false); // superseded searches no longer own the spinner
    setAutoProgress(null);
    setScenes([]); setSelectedScene(null); setAnalysis(null); setLayers({});
    setUserImg(null); setImgError(null);
  }, []);

  const onFile = useCallback(async (f: File) => {
    setUploadError(null);
    try {
      const aoi = await parseAoiFile(f);
      setAoi(aoi, aoi.properties.name ?? 'My field');
      clearWorkspace();
    } catch (e: unknown) {
      setUploadError(errorMessage(e) ?? 'Could not read the file.');
    }
  }, [setAoi, clearWorkspace]);

  const loadDemo = useCallback(() => {
    setUploadError(null);
    setAoi(DEMO_AOI, DEMO_AOI.properties.name ?? 'Demo field');
    clearWorkspace();
  }, [setAoi, clearWorkspace]);

  const resetAll = useCallback(() => {
    clearWorkspace();
    reset();
    setUploadError(null);
    setSceneError(null);
    setBusy(null);
  }, [clearWorkspace, reset]);

  const onAoiDrawn = useCallback((feature: GeoJSON.Feature<GeoJSON.Polygon>) => {
    setUploadError(null);
    // simplify the freehand sketch (Douglas–Peucker) so downloads stay light
    const aoi: AoiFeature = {
      type: 'Feature',
      geometry: simplifyPolygon(feature.geometry),
      properties: { name: 'Drawn field' },
    };
    setAoi(aoi, 'Drawn field');
    clearWorkspace();
  }, [setAoi, clearWorkspace]);

  /* ---------- user-supplied imagery (Cartosat-2 products, drone GeoTIFFs…) ---------- */
  const onUserFile = useCallback(async (f: File) => {
    setImgError(null);
    setImgLoading(true);
    try {
      const info = await inspectUserImage(f);
      const det = detectBandMapping(info.bandCount, info.bandLabels);
      setUserImg({ ...info, mapping: det.mapping, mappingSource: det.source });
    } catch {
      setImgError('Could not read this file. Use a georeferenced GeoTIFF (.tif) — e.g., a Cartosat-2 product or drone mosaic.');
      setUserImg(null);
    } finally {
      setImgLoading(false);
    }
  }, []);

  const updateMapping = useCallback((key: keyof BandMapping, value: number | undefined) => {
    setUserImg((u) => (u ? { ...u, mapping: { ...u.mapping, [key]: value } } : u));
  }, []);

  const addUserScene = useCallback(() => {
    if (!userImg) return;
    const scene: SceneInfo = {
      id: `upload:${Date.now()}`,
      datetime: new Date().toISOString(),
      cloudCover: 0,
      bbox: aoiBBox ? [...aoiBBox] : [0, 0, 0, 0],
      assets: {},
    };
    setScenes((prev) => [scene, ...prev]);
    setSelectedScene(scene);
  }, [userImg, aoiBBox]);


  /**
   * Background season-trend builder: after every scene search, automatically compute
   * NDVI + NDMI for the 10 newest Sentinel-2 scenes (from today backwards) so the
   * trend chart fills in without the farmer clicking anything. Cancellable via token —
   * any field change invalidates the run.
   */
  const analyzeLatest = useCallback((found: SceneInfo[], aoi: AoiFeature) => {
    const bbox = geoBBox(aoi.geometry);
    const geom = aoi.geometry;
    const token = ++trendTokenRef.current;
    const targets = found.filter((s) => !s.id.startsWith('upload:')).slice(0, 10);
    if (!targets.length) return;
    const defs = ['ndvi', 'ndmi'].map((id) => INDEX_DEFS.find((d) => d.id === id)!);
    setAutoProgress({ done: 0, total: targets.length });
    void (async () => {
      for (let i = 0; i < targets.length; i++) {
        const scene = targets[i];
        const cache: RasterCache = new Map();
        for (const def of defs) {
          if (trendTokenRef.current !== token) return;
          const key = `${scene.id}:${def.id}`;
          if (layersRef.current[key]) continue; // already computed
          try {
            const comp = await computeIndex(def, scene.assets, bbox, geom, undefined, cache);
            const res: AnalysisResult = {
              indexId: def.id, stats: comp.stats, imageDataUrl: renderIndexImage(comp, def),
              bounds: comp.bounds, sceneId: scene.id, sceneDate: scene.datetime.slice(0, 10),
              computedAt: new Date().toISOString(),
            };
            setLayers((m) => ({ ...m, [key]: res }));
            layersRef.current = { ...layersRef.current, [key]: res };
            pushHistory(def.id === 'ndvi'
              ? { sceneId: scene.id, date: res.sceneDate, ndviMean: res.stats!.mean, cloudCover: scene.cloudCover }
              : { sceneId: scene.id, date: res.sceneDate, ndmiMean: res.stats!.mean, cloudCover: scene.cloudCover });
          } catch {
            // scene unreadable (e.g. missing band) — skip it, keep going
          }
        }
        if (trendTokenRef.current !== token) return;
        setAutoProgress({ done: i + 1, total: targets.length });
      }
      setAutoProgress(null);
    })();
  }, [pushHistory]);

  // only the most recent search may apply its results; previous requests are aborted
  const searchSeqRef = useRef(0);
  const searchAbortRef = useRef<AbortController | null>(null);
  const autoAttemptRef = useRef<string | null>(null);

  const refreshScenes = useCallback(async (auto = false) => {
    const aoi = state.aoi;
    if (!aoi) return;
    const seq = ++searchSeqRef.current;
    searchAbortRef.current?.abort();
    const controller = new AbortController();
    searchAbortRef.current = controller;
    setScenesLoading(true);
    setSceneError(null);
    try {
      const found = await searchScenes(aoi.geometry, state.fromDate, maxCloud, 30, controller.signal);
      if (searchSeqRef.current !== seq) return;
      // keep any user-uploaded image scenes at the top of the list
      setScenes((prev) => [...prev.filter((s) => s.id.startsWith('upload:')), ...found]);
      markRun();
      setSelectedScene((cur) => {
        if (cur?.id.startsWith('upload:')) return cur; // don't steal selection from an uploaded scene
        return found.length && (auto || !cur) ? found[0] : cur;
      });
      if (!found.length) setSceneError(`No clear Sentinel-2 scenes since ${state.fromDate}. Try raising the cloud limit.`);
      else analyzeLatest(found, aoi);
    } catch (e: unknown) {
      if (searchSeqRef.current === seq && !(e instanceof DOMException && e.name === 'AbortError')) {
        setSceneError(errorMessage(e) ?? 'Scene search failed.');
      }
    } finally {
      if (searchSeqRef.current === seq) {
        setScenesLoading(false);
        if (searchAbortRef.current === controller) searchAbortRef.current = null;
      }
    }
  }, [state.aoi, state.fromDate, maxCloud, markRun, analyzeLatest]);

  // One automatic attempt per field/date/run. A failure never creates a retry loop;
  // the farmer can still retry explicitly with "Check for new imagery".
  useEffect(() => {
    if (!state.aoi || !status.due || scenesLoading) return;
    const attemptKey = `${state.aoiName}:${state.fromDate}:${state.lastRunAt ?? 'never'}`;
    if (autoAttemptRef.current === attemptKey) return;
    autoAttemptRef.current = attemptKey;
    void refreshScenes(true);
  }, [state.aoi, state.aoiName, state.fromDate, state.lastRunAt, status.due, scenesLoading, refreshScenes]);

  useEffect(() => () => {
    trendTokenRef.current++;
    searchAbortRef.current?.abort();
  }, []);

  /* ---------- layer computation (true-color image + indices) ---------- */
  const runAnalysis = useCallback(async (layerId: LayerId) => {
    if (!state.aoi || !selectedScene || !aoiBBox) return;
    const key = `${selectedScene.id}:${layerId}`;
    const cached = layers[key];
    if (cached) { setAnalysis(cached); return; }
    try {
      // uploaded imagery (Cartosat-2, drone…) — compute from the user's file
      if (selectedScene.id.startsWith('upload:')) {
        if (!userImg) throw new Error('Upload a GeoTIFF image first.');
        if (layerId === 'tci') {
          setBusy('Rendering your image…');
          const tci = await renderUserTrueColor(userImg, userImg.mapping, aoiBBox, state.aoi.geometry, setBusy);
          const result: AnalysisResult = {
            indexId: 'tci', stats: null, imageDataUrl: tci.imageDataUrl, bounds: tci.bounds,
            sceneId: selectedScene.id, sceneDate: selectedScene.datetime.slice(0, 10),
            computedAt: new Date().toISOString(),
          };
          setLayers((m) => ({ ...m, [key]: result }));
          setAnalysis(result);
          return;
        }
        const udef = INDEX_DEFS.find((d) => d.id === layerId)!;
        setBusy(`Preparing ${udef.name}…`);
        const ucomp = await computeUserIndex(userImg, udef, userImg.mapping, aoiBBox, state.aoi.geometry, setBusy);
        const uimg = renderIndexImage(ucomp, udef);
        const ures: AnalysisResult = {
          indexId: layerId, stats: ucomp.stats, imageDataUrl: uimg,
          bounds: ucomp.bounds, sceneId: selectedScene.id,
          sceneDate: selectedScene.datetime.slice(0, 10), computedAt: new Date().toISOString(),
        };
        setLayers((m) => ({ ...m, [key]: ures }));
        setAnalysis(ures);
        if (layerId === 'ndvi') {
          pushHistory({ sceneId: selectedScene.id, date: ures.sceneDate, ndviMean: ures.stats!.mean, cloudCover: 0 });
        } else if (layerId === 'ndmi') {
          pushHistory({ sceneId: selectedScene.id, date: ures.sceneDate, ndmiMean: ures.stats!.mean, cloudCover: 0 });
        }
        return;
      }
      if (layerId === 'tci') {
        setBusy('Preparing satellite image…');
        const tci = await readTrueColor(selectedScene.assets, aoiBBox, state.aoi.geometry, setBusy);
        const result: AnalysisResult = {
          indexId: 'tci', stats: null,
          imageDataUrl: tci.imageDataUrl, bounds: tci.bounds,
          sceneId: selectedScene.id, sceneDate: selectedScene.datetime.slice(0, 10),
          computedAt: new Date().toISOString(),
        };
        setLayers((m) => ({ ...m, [key]: result }));
        setAnalysis(result);
        return;
      }
      const def = INDEX_DEFS.find((d) => d.id === layerId)!;
      setBusy(`Preparing ${def.name}…`);
      const computed = await computeIndex(def, selectedScene.assets, aoiBBox, state.aoi.geometry, setBusy);
      const imageDataUrl = renderIndexImage(computed, def);
      const result: AnalysisResult = {
        indexId: layerId, stats: computed.stats, imageDataUrl,
        bounds: computed.bounds, sceneId: selectedScene.id,
        sceneDate: selectedScene.datetime.slice(0, 10), computedAt: new Date().toISOString(),
      };
      setLayers((m) => ({ ...m, [key]: result }));
      setAnalysis(result);
      if (layerId === 'ndvi') {
        pushHistory({ sceneId: selectedScene.id, date: result.sceneDate, ndviMean: result.stats!.mean, cloudCover: selectedScene.cloudCover });
      } else if (layerId === 'ndmi') {
        pushHistory({ sceneId: selectedScene.id, date: result.sceneDate, ndmiMean: result.stats!.mean, cloudCover: selectedScene.cloudCover });
      }
    } catch (e: unknown) {
      setSceneError(errorMessage(e) ?? 'Analysis failed.');
    } finally {
      setBusy(null);
    }
  }, [state.aoi, selectedScene, aoiBBox, pushHistory, layers, userImg]);

  // which layers the current scene supports (all for Sentinel-2; band-dependent for uploads)
  const layerAvailability = useMemo<LayerId[]>(() => {
    if (!selectedScene) return [];
    if (!selectedScene.id.startsWith('upload:')) return ['tci', ...INDEX_DEFS.map((d) => d.id)];
    return userImg ? availableLayers(userImg, userImg.mapping) : [];
  }, [selectedScene, userImg]);

  // layers computed for the currently selected scene (for the map layer switcher)
  const sceneLayers = useMemo(
    () => Object.values(layers).filter((l) => l.sceneId === selectedScene?.id),
    [layers, selectedScene],
  );

  // merge history points for the trend chart (same scene may carry ndvi + ndmi rows)
  const trendData = (() => {
    const m = new Map<string, { date: string; ndvi?: number; ndmi?: number }>();
    for (const h of state.history) {
      const row = m.get(h.sceneId) ?? { date: h.date };
      if (h.ndviMean !== undefined) row.ndvi = Math.round(h.ndviMean * 1000) / 1000;
      if (h.ndmiMean !== undefined) row.ndmi = Math.round(h.ndmiMean * 1000) / 1000;
      m.set(h.sceneId, row);
    }
    return [...m.values()].sort((a, b) => a.date.localeCompare(b.date));
  })();

  const prevPoint = state.history.length > 1 ? state.history[state.history.length - 2] : undefined;
  const decisions = analysis?.stats
    ? buildDecisions(analysis.indexId as IndexId, analysis.stats, prevPoint)
    : [];
  const activeDef: IndexDef = INDEX_DEFS.find((d) => d.id === activeIndex)!;

  const sevStyle = { good: 'border-emerald-600/40 bg-emerald-50', watch: 'border-amber-500/40 bg-amber-50', act: 'border-red-500/40 bg-red-50' } as const;
  const sevIcon = { good: <CheckCircle2 className="h-5 w-5 text-emerald-600" />, watch: <AlertTriangle className="h-5 w-5 text-amber-600" />, act: <AlertTriangle className="h-5 w-5 text-red-600" /> } as const;

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-background text-foreground">
      {/* top bar */}
      <header className="z-[700] flex h-14 shrink-0 items-center gap-3 border-b border-[#354F52] bg-[#2F3E46] px-4 text-[#CAD2C5] shadow-md md:px-5">
        <button
          onClick={() => setPanelOpen((v) => !v)}
          title={panelOpen ? 'Hide panel' : 'Show panel'}
          className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm font-medium text-[#CAD2C5] transition-colors hover:bg-[#354F52] hover:text-[#CAD2C5] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#84A98C]"
        >
          {panelOpen ? <PanelLeftClose className="h-4.5 w-4.5" /> : <PanelLeftOpen className="h-4.5 w-4.5" />}
          <span className="hidden sm:inline">{panelOpen ? 'Hide panel' : 'Panel'}</span>
        </button>
        <div className="flex min-w-0 items-center gap-2.5">
          <Sprout className="h-6 w-6 shrink-0 text-[#CAD2C5]" aria-hidden />
          <h1 className="truncate font-display text-base font-bold leading-tight md:text-lg">Farm Monitor</h1>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {state.aoi && (
            <Badge variant="secondary" className="gap-1.5 bg-emerald-800 text-emerald-50 hover:bg-emerald-800">
              <CalendarClock className="h-3.5 w-3.5" />
              {status.due ? 'Update due now' : `Next update in ${status.daysRemaining}d`}
            </Badge>
          )}
          <Button variant="ghost" size="sm" className="text-emerald-100 hover:bg-emerald-800 hover:text-white" onClick={resetAll}>
            Reset
          </Button>
        </div>
      </header>

      {/* map-centric workspace (ArcGIS Online style) */}
      <div className="relative flex-1 overflow-hidden">
        {/* full-bleed map */}
        <main className="absolute inset-0">
          <MapView aoi={state.aoi} overlay={analysis} opacity={overlayOpacity} zoomSignal={zoomSignal} onAoiDrawn={onAoiDrawn} />

          {/* zoom to layer widget */}
          {state.aoi && (
            <button
              onClick={() => setZoomSignal((n) => n + 1)}
              title="Zoom to field boundary"
              className={`absolute right-3 top-40 z-[500] flex items-center gap-1.5 rounded-md border border-stone-300 bg-white/95 px-2.5 py-1.5 text-xs font-medium text-stone-700 shadow-md transition-colors hover:bg-emerald-50 hover:text-emerald-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600/40 ${panelOpen ? 'max-lg:hidden' : ''}`}
            >
              <Maximize2 className="h-3.5 w-3.5" /> Zoom to field
            </button>
          )}

          {/* layer switcher widget */}
          {sceneLayers.length > 0 && (
            <div className="absolute bottom-4 right-4 z-[500] w-48 rounded-lg border border-stone-200 bg-white/95 p-3 shadow-lg backdrop-blur">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-stone-500">
                <Layers className="h-3.5 w-3.5" /> Map layers
              </p>
              <div className="flex flex-wrap gap-1">
                {sceneLayers.map((l) => (
                  <button
                    key={l.indexId}
                    onClick={() => setAnalysis(l)}
                    className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600/40 ${
                      analysis?.indexId === l.indexId
                        ? 'border-emerald-700 bg-emerald-700 text-white'
                        : 'border-stone-300 bg-white text-stone-700 hover:border-emerald-600/50 hover:bg-emerald-50'
                    }`}
                  >
                    {LAYER_LABELS[l.indexId]}
                  </button>
                ))}
              </div>
              <label className="mt-2.5 block text-xs text-stone-500">
                Layer opacity {Math.round(overlayOpacity * 100)}%
                <input
                  type="range" min={0.2} max={1} step={0.05} value={overlayOpacity}
                  onChange={(e) => setOverlayOpacity(Number(e.target.value))}
                  className="mt-1 w-full accent-emerald-700"
                />
              </label>
            </div>
          )}

          {/* empty state */}
          {!state.aoi && (
            <div className="pointer-events-none absolute inset-0 z-[500] flex items-center justify-center bg-stone-900/30 p-4">
              <div className="max-w-sm rounded-lg bg-white/95 p-6 text-center shadow-xl">
                <MapPin className="mx-auto h-10 w-10 text-emerald-700" />
                <h2 className="mt-2 font-display text-lg font-bold">Start with your field</h2>
                <p className="mt-1 text-sm text-stone-600">
                  Open the panel and upload a zipped shapefile of your field boundary, draw it with the
                  map's polygon tool (top-right), or load the demo field to explore.
                </p>
              </div>
            </div>
          )}
        </main>

        {/* floating contents panel */}
        <aside
          className={`absolute bottom-3 left-3 top-3 z-[600] flex w-[min(400px,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-xl border border-stone-200 bg-white/95 shadow-2xl backdrop-blur transition-transform duration-200 ease-out ${
            panelOpen ? 'translate-x-0' : '-translate-x-[calc(100%+1rem)]'
          }`}
          aria-hidden={!panelOpen}
        >
          <div className="flex shrink-0 items-center justify-between border-b border-stone-200 px-4 py-2.5">
            <p className="font-display text-sm font-semibold text-stone-700">Contents</p>
            <button
              onClick={() => setPanelOpen(false)}
              title="Close panel"
              className="rounded p-1 text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600/40"
            >
              <PanelLeftClose className="h-4 w-4" />
            </button>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {/* STEP 1 — field */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <MapPin className="h-5 w-5 text-emerald-700" /> 1 · Your field (area of interest)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <input
                key={fileInputKey}
                id="aoi-file-input"
                type="file"
                accept=".zip,.geojson,.json"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); setFileInputKey((k) => k + 1); }}
              />
              <Button className="w-full bg-emerald-700 hover:bg-emerald-800" onClick={() => document.getElementById('aoi-file-input')?.click()}>
                <Upload className="mr-2 h-4 w-4" /> Upload field shapefile (.zip)
              </Button>
              <p className="text-xs text-stone-500">
                Zip the .shp, .shx, .dbf and .prj files together. Coordinates must be WGS&nbsp;84 (EPSG:4326).
              </p>
              <Button variant="outline" className="w-full" onClick={loadDemo}>
                Try a demo field
              </Button>
              <div className="flex items-start gap-2 rounded-md border border-dashed border-emerald-600/50 bg-emerald-50/70 p-2 text-xs text-emerald-900">
                <PenLine className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  No shapefile? Use the polygon tool on the map toolbar (top-right) to draw your field
                  boundary — click corner points, then double-click to finish.
                </span>
              </div>
              {uploadError && <p className="text-sm text-red-600">{uploadError}</p>}
              {state.aoi && (
                <div className="rounded-md bg-emerald-50 p-3 text-sm">
                  <p className="font-medium text-emerald-900">{state.aoiName}</p>
                  <p className="text-emerald-800/80">Area ≈ {aoiArea.toFixed(1)} hectares</p>
                </div>
              )}
              <label className="block text-sm">
                <span className="mb-1 block font-medium">Monitoring start date</span>
                <input
                  type="date"
                  value={state.fromDate}
                  max={new Date().toISOString().slice(0, 10)}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full rounded-md border border-stone-300 bg-white px-3 py-2 text-sm focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
                />
              </label>
            </CardContent>
          </Card>

          {/* STEP 2 — satellite updates */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Satellite className="h-5 w-5 text-emerald-700" /> 2 · Satellite updates
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-stone-600">Auto-refresh every {UPDATE_INTERVAL_DAYS} days</span>
                  <span className="font-medium">{status.due ? 'Due now' : `${status.daysRemaining}d left`}</span>
                </div>
                <Progress value={status.due ? 100 : ((UPDATE_INTERVAL_DAYS - status.daysRemaining) / UPDATE_INTERVAL_DAYS) * 100} className="h-2" />
              </div>
              <label className="block text-sm">
                <span className="mb-1 block font-medium">Cloud cover limit: {maxCloud}%</span>
                <input
                  type="range" min={5} max={80} step={5} value={maxCloud}
                  onChange={(e) => setMaxCloud(Number(e.target.value))}
                  className="w-full accent-emerald-700"
                />
              </label>
              <Button
                className="w-full bg-emerald-700 hover:bg-emerald-800"
                disabled={!state.aoi || scenesLoading}
                onClick={() => refreshScenes(false)}
              >
                {scenesLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                {scenesLoading ? 'Searching satellite archive…' : 'Check for new imagery'}
              </Button>
              {sceneError && <p className="text-sm text-red-600">{sceneError}</p>}
              {autoProgress && (
                <p className="flex items-center gap-2 rounded-md bg-emerald-50 p-2 text-xs text-emerald-800">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Building the season trend — analysing scene {autoProgress.done}/{autoProgress.total} (NDVI + NDMI)…
                </p>
              )}
              {scenes.length > 0 && (
                <div className="max-h-44 space-y-1 overflow-y-auto rounded-md border border-stone-200 p-1">
                  {scenes.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setSelectedScene(s)}
                      className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left text-sm transition-colors hover:bg-emerald-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600/40 ${selectedScene?.id === s.id ? 'bg-emerald-100 font-medium' : ''}`}
                    >
                      <span className="flex items-center gap-2">
                        <CloudRain className="h-3.5 w-3.5 text-stone-400" />
                        {s.datetime.slice(0, 10)}
                      </span>
                      <span className="text-xs text-stone-500">{Math.round(s.cloudCover)}% cloud</span>
                    </button>
                  ))}
                </div>
              )}
              {/* own imagery upload */}
              <div className="flex items-center gap-2 pt-1">
                <div className="h-px flex-1 bg-stone-200" />
                <span className="text-xs text-stone-400">or use your own imagery</span>
                <div className="h-px flex-1 bg-stone-200" />
              </div>
              <input
                id="user-img-input"
                type="file"
                accept=".tif,.tiff"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) onUserFile(f); e.target.value = ''; }}
              />
              <Button
                variant="outline"
                className="w-full"
                disabled={!state.aoi || imgLoading}
                onClick={() => document.getElementById('user-img-input')?.click()}
              >
                {imgLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileImage className="mr-2 h-4 w-4" />}
                Upload GeoTIFF (Cartosat-2, drone…)
              </Button>
              {imgError && <p className="text-sm text-red-600">{imgError}</p>}
              {userImg && (
                <div className="space-y-2 rounded-md border border-stone-200 bg-stone-50 p-2.5 text-sm">
                  <p className="font-medium leading-snug">{userImg.file.name}</p>
                  <p className="text-xs text-stone-500">{userImg.bandCount} band{userImg.bandCount > 1 ? 's' : ''} · {userImg.crsName}</p>
                  {userImg.bandCount > 1 && (
                    <p className={`rounded border p-1.5 text-xs ${userImg.mappingSource === 'metadata'
                      ? 'border-emerald-600/40 bg-emerald-50 text-emerald-800'
                      : 'border-amber-500/40 bg-amber-50 text-amber-800'}`}>
                      {userImg.mappingSource === 'metadata'
                        ? 'Bands auto-detected from the file metadata — verify the mapping below.'
                        : `No band names in the file — guessed by band order (${userImg.bandCount >= 5
                          ? 'Blue, Green, Red, Red-edge, NIR (MicaSense / DJI multispectral)'
                          : userImg.bandCount === 4
                            ? 'Red, Green, Blue, NIR (typical drone / Cartosat-2 MX)'
                            : 'Red, Green, Blue'}). Please verify below.`}
                    </p>
                  )}
                  {userImg.bandCount > 1 && (
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['red', 'green', 'blue', 'nir', 'swir', 'rededge'] as const).map((k) => (
                        <label key={k} className="text-xs">
                          <span className="mb-0.5 block font-medium uppercase text-stone-500">{k === 'nir' ? 'NIR' : k === 'swir' ? 'SWIR' : k}</span>
                          <select
                            value={userImg.mapping[k] ?? ''}
                            onChange={(e) => updateMapping(k, e.target.value === '' ? undefined : Number(e.target.value))}
                            className="w-full rounded border border-stone-300 bg-white px-1.5 py-1 text-xs focus:border-emerald-600 focus:outline-none"
                          >
                            <option value="">—</option>
                            {Array.from({ length: userImg.bandCount }, (_, i) => i + 1).map((n) => (
                              <option key={n} value={n}>Band {n}</option>
                            ))}
                          </select>
                        </label>
                      ))}
                    </div>
                  )}
                  <Button size="sm" className="w-full bg-emerald-700 hover:bg-emerald-800" onClick={addUserScene}>
                    Add as scene
                  </Button>
                  <p className="text-xs text-stone-500">
                    Bands without SWIR/red-edge limit NDMI & NDRE; EVI & SAVI need calibrated reflectance, so they stay Sentinel-2-only.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* STEP 3 — analysis */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Leaf className="h-5 w-5 text-emerald-700" /> 3 · Satellite image & analysis layers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant={analysis?.indexId === 'tci' ? 'default' : 'outline'}
                size="sm"
                className={`w-full justify-start ${analysis?.indexId === 'tci' ? 'bg-emerald-700 hover:bg-emerald-800' : ''}`}
                disabled={!selectedScene || !!busy || !layerAvailability.includes('tci')}
                title={selectedScene && !layerAvailability.includes('tci') ? 'This image has no RGB bands mapped' : undefined}
                onClick={() => runAnalysis('tci')}
              >
                <ImageIcon className="mr-1.5 h-4 w-4 shrink-0" />
                Satellite image (true color)
              </Button>
              <div className="grid grid-cols-2 gap-2">
                {INDEX_DEFS.map((def) => {
                  const Icon = INDEX_ICONS[def.id];
                  return (
                    <Button
                      key={def.id}
                      variant={activeIndex === def.id && analysis?.indexId === def.id ? 'default' : 'outline'}
                      size="sm"
                      className={`justify-start ${activeIndex === def.id && analysis?.indexId === def.id ? 'bg-emerald-700 hover:bg-emerald-800' : ''}`}
                      disabled={!selectedScene || !!busy || !layerAvailability.includes(def.id)}
                      title={selectedScene && !layerAvailability.includes(def.id) ? 'Required bands not available in this image' : undefined}
                      onClick={() => { setActiveIndex(def.id); runAnalysis(def.id); }}
                    >
                      <Icon className="mr-1.5 h-4 w-4 shrink-0" />
                      <span className="truncate">{def.id.toUpperCase()}</span>
                    </Button>
                  );
                })}
              </div>
              {busy && (
                <p className="flex items-center gap-2 text-sm text-stone-600">
                  <Loader2 className="h-4 w-4 animate-spin" /> {busy}
                </p>
              )}
              {analysis && (
                <div className="space-y-3">
                  <p className="text-sm text-stone-600">
                    {analysis.indexId === 'tci'
                      ? `True-color Sentinel-2 image of your field (${analysis.sceneDate}). Use the layer panel on the map to compare it with the analysis layers.`
                      : activeDef.what}
                  </p>
                  {analysis.stats && analysis.indexId !== 'tci' && (
                    <>
                      <div className="grid grid-cols-3 gap-2 text-center">
                        {[
                          ['Mean', analysis.stats.mean],
                          ['Min', analysis.stats.min],
                          ['Max', analysis.stats.max],
                        ].map(([label, v]) => (
                          <div key={label as string} className="rounded-md bg-stone-100 p-2">
                            <p className="text-xs text-stone-500">{label}</p>
                            <p className="font-display text-lg font-semibold">{(v as number).toFixed(2)}</p>
                          </div>
                        ))}
                      </div>
                      {/* legend */}
                      <div className="space-y-1">
                        {analysis.stats.classes.map((c) => (
                          <div key={c.label} className="flex items-center gap-2 text-sm">
                            <span className="h-3 w-3 rounded-sm" style={{ backgroundColor: c.color }} />
                            <span className="flex-1">{c.label}</span>
                            <span className="font-medium">{c.pct}%</span>
                          </div>
                        ))}
                      </div>
                      {/* decisions */}
                      <div className="space-y-2 border-t border-stone-200 pt-3">
                        <p className="font-display font-semibold">What to do</p>
                        {decisions.map((d, i) => (
                          <div key={i} className={`rounded-md border p-3 ${sevStyle[d.severity]}`}>
                            <div className="flex items-start gap-2">
                              {sevIcon[d.severity]}
                              <div>
                                <p className="font-medium leading-snug">{d.title}</p>
                                <p className="mt-0.5 text-sm text-stone-700">{d.detail}</p>
                                <p className="mt-1 text-sm font-medium text-stone-900">→ {d.action}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* trend chart */}
          {trendData.length > 0 && (
            <Card className="border-[#52796F] bg-[#CAD2C5]">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Season trend (10-day updates)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData} margin={{ top: 4, right: 8, bottom: 0, left: -18 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#84A98C" />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#2F3E46' }} />
                      <YAxis domain={[-0.5, 1]} tick={{ fontSize: 11, fill: '#2F3E46' }} />
                      <Tooltip contentStyle={{ backgroundColor: '#CAD2C5', borderColor: '#52796F', color: '#2F3E46' }} />
                      <Area type="monotone" dataKey="ndvi" name="NDVI (health)" stroke="#16a34a" fill="#16a34a" fillOpacity={0.28} connectNulls />
                      <Area type="monotone" dataKey="ndmi" name="NDMI (moisture)" stroke="#2563eb" strokeDasharray="5 3" fill="#2563eb" fillOpacity={0.32} connectNulls />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* roadmap & references */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Analysis roadmap & research</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="roadmap">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="roadmap" className="gap-1.5"><ListChecks className="h-4 w-4" /> Analyses</TabsTrigger>
                  <TabsTrigger value="refs" className="gap-1.5"><BookOpen className="h-4 w-4" /> Papers</TabsTrigger>
                </TabsList>
                <TabsContent value="roadmap" className="mt-3 space-y-2">
                  {ANALYSIS_ROADMAP.map((r) => (
                    <div key={r.title} className="rounded-md border border-stone-200 p-2.5 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant={r.status === 'implemented' ? 'default' : 'secondary'} className={r.status === 'implemented' ? 'bg-emerald-700' : ''}>
                          {r.status === 'implemented' ? 'In app' : 'Next'}
                        </Badge>
                        <p className="font-medium leading-snug">{r.title}</p>
                      </div>
                      <p className="mt-1 text-stone-600">{r.how}</p>
                      {r.ref && <p className="mt-0.5 text-xs italic text-stone-500">Based on: {r.ref}</p>}
                    </div>
                  ))}
                </TabsContent>
                <TabsContent value="refs" className="mt-3 space-y-2">
                  {REFERENCES.map((p) => (
                    <a
                      key={p.url}
                      href={p.url}
                      target="_blank"
                      rel="noreferrer"
                      className="block rounded-md border border-stone-200 p-2.5 text-sm transition-colors hover:border-emerald-600/50 hover:bg-emerald-50/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600/40"
                    >
                      <p className="font-medium leading-snug">{p.title}</p>
                      <p className="mt-0.5 text-xs text-stone-500">{p.authors} · {p.year} · {p.venue}</p>
                      <p className="mt-0.5 text-xs text-emerald-800">Used for: {p.usedFor}</p>
                    </a>
                  ))}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          </div>
        </aside>
      </div>
    </div>
  );
}
