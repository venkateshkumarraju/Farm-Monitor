import { spawnSync } from 'node:child_process';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 20 || (major === 20 && minor < 19)) {
  console.error(`Node.js 20.19.0 or newer is required. Found ${process.version}.`);
  process.exit(1);
}

const windows = process.platform === 'win32';
const command = windows ? (process.env.ComSpec ?? 'cmd.exe') : 'npm';
function run(args, label) {
  console.log(`\n==> ${label}`);
  const commandArgs = windows ? ['/d', '/s', '/c', 'npm', ...args] : args;
  const result = spawnSync(command, commandArgs, { stdio: 'inherit', shell: false });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}

run(['ci'], 'Install exact dependencies from package-lock.json');
run(['run', 'check'], 'Run lint, unit tests, and production build');
run(['audit', '--omit=dev'], 'Audit production dependencies');
console.log('\nFarm Monitor is ready. Start it with: npm run dev');
