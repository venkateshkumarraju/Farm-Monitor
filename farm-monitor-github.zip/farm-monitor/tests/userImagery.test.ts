import test from 'node:test';
import assert from 'node:assert/strict';
import { availableLayers, detectBandMapping, heuristicMapping } from '../src/lib/userImagery.ts';
import type { UserImageInfo } from '../src/lib/userImagery.ts';

test('RGB and RGB+NIR fallback mappings follow common drone exports', () => {
  assert.deepEqual(heuristicMapping(3), { red: 1, green: 2, blue: 3 });
  assert.deepEqual(heuristicMapping(4), { red: 1, green: 2, blue: 3, nir: 4 });
  assert.deepEqual(heuristicMapping(5), { blue: 1, green: 2, red: 3, rededge: 4, nir: 5 });
});

test('metadata band names take precedence over band-order guesses', () => {
  const detected = detectBandMapping(4, ['blue', 'green', 'red', 'near infrared']);
  assert.equal(detected.source, 'metadata');
  assert.deepEqual(detected.mapping, { blue: 1, green: 2, red: 3, nir: 4 });
});

test('red-edge detection is not confused with the red band', () => {
  const detected = detectBandMapping(5, ['blue', 'green', 'red', 'red edge', 'nir']);
  assert.deepEqual(detected.mapping, { blue: 1, green: 2, red: 3, rededge: 4, nir: 5 });
});

test('RGB+NIR imagery exposes only supported analysis layers', () => {
  const info: UserImageInfo = {
    file: new File(['test'], 'field.tif'), bandCount: 4, width: 100, height: 100,
    crsName: 'EPSG:4326', bandLabels: [null, null, null, null],
  };
  const layers = availableLayers(info, heuristicMapping(4));
  assert.deepEqual(layers, ['tci', 'ndvi', 'ndwi']);
});
