import test from 'node:test';
import assert from 'node:assert/strict';
import { areaHectares, DEMO_AOI, geoBBox, simplifyPolygon } from '../src/lib/geo.ts';

test('demo field has a valid WGS 84 bounding box', () => {
  assert.deepEqual(geoBBox(DEMO_AOI.geometry), [75.8, 30.865, 75.812, 30.875]);
});

test('polygon area subtracts interior holes', () => {
  const outer = [[[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]];
  const withHole = [[...outer[0]], [[0.2, 0.2], [0.2, 0.8], [0.8, 0.8], [0.8, 0.2], [0.2, 0.2]]];
  const full = areaHectares({ type: 'Polygon', coordinates: outer });
  const holed = areaHectares({ type: 'Polygon', coordinates: withHole });
  assert.ok(full > 12_000);
  assert.ok(Math.abs(holed / full - 0.64) < 0.001);
});

test('drawn polygon simplification preserves a closed valid ring', () => {
  const simplified = simplifyPolygon({
    type: 'Polygon',
    coordinates: [[[0, 0], [0.5, 0], [1, 0], [1, 1], [0, 1], [0, 0]]],
  });
  assert.deepEqual(simplified.coordinates[0], [[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]);
});

test('empty geometry is rejected instead of returning an infinite bbox', () => {
  assert.throws(() => geoBBox({ type: 'Polygon', coordinates: [] }), /no valid coordinates/);
});
