import test from 'node:test';
import assert from 'node:assert/strict';
import { checkpoints, sceneNear, updateStatus, UPDATE_INTERVAL_DAYS } from '../src/lib/stac.ts';
import type { SceneInfo } from '../src/types/index.ts';

test('update cycle is ten days', () => {
  assert.equal(UPDATE_INTERVAL_DAYS, 10);
  const status = updateStatus('2026-01-01', null, new Date('2026-01-05T00:00:00Z'));
  assert.equal(status.due, false);
  assert.equal(status.daysRemaining, 6);
});

test('a due update becomes current after a successful run', () => {
  assert.equal(updateStatus('2026-01-01', null, new Date('2026-01-11T00:00:00Z')).due, true);
  const status = updateStatus('2026-01-01', '2026-01-11T00:00:00Z', new Date('2026-01-12T00:00:00Z'));
  assert.equal(status.due, false);
  assert.equal(status.nextUpdateAt.toISOString(), '2026-01-21T00:00:00.000Z');
});

test('checkpoints use the same ten-day interval', () => {
  const points = checkpoints('2026-01-01T00:00:00Z', new Date('2026-01-31T00:00:00Z'));
  assert.deepEqual(points.map((d) => d.toISOString().slice(0, 10)), ['2026-01-01', '2026-01-11', '2026-01-21', '2026-01-31']);
});

test('sceneNear selects the closest acquisition', () => {
  const scene = (id: string, datetime: string): SceneInfo => ({ id, datetime, cloudCover: 0, bbox: [], assets: {} });
  const scenes = [scene('old', '2026-01-01T00:00:00Z'), scene('near', '2026-01-10T00:00:00Z')];
  assert.equal(sceneNear(scenes, new Date('2026-01-11T00:00:00Z'))?.id, 'near');
  assert.equal(sceneNear([], new Date()), null);
});
