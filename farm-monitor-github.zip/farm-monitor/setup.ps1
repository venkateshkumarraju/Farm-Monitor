$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
node scripts/setup.mjs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
