import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

// https://vite.dev/config/
export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    port: 3000,
  },
  build: {
    rollupOptions: {
      output: {
        // split the heavy GIS libs into lazy-friendly chunks
        manualChunks: {
          geotiff: ['geotiff'],
          leaflet: ['leaflet'],
          shapefile: ['shpjs'],
          charts: ['recharts'],
        },
      },
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
